@extends('layouts.app')


<!-- Start Page Heading Section -->
<section class="td_page_heading td_center td_bg_filed td_heading_bg text-center td_hobble" data-src="{{ asset('assets/img/others/page_heading_bg.jpg') }}">
  <div class="container">
    <div class="td_page_heading_in">
      <h1 class="td_white_color td_fs_48 td_mb_10">About Us</h1>
      <ol class="breadcrumb m-0 td_fs_20 td_opacity_8 td_semibold td_white_color">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active">About Us</li>
      </ol>
    </div>
  </div>
  <div class="td_page_heading_shape_1 position-absolute td_hover_layer_3"></div>
  <div class="td_page_heading_shape_2 position-absolute td_hover_layer_5"></div>
  <div class="td_page_heading_shape_3 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_3.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_4 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_4.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_5 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_5.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_6 position-absolute td_hover_layer_3"></div>
</section>
<!-- End Page Heading Section -->


<!-- Start About Section -->
<section>
  <div class="td_height_120 td_height_lg_80"></div>
  <div class="td_about td_style_1">
    <div class="container">
      <div class="row align-items-center td_gap_y_40">
        <div class="col-lg-6 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.25s">
          <div class="td_about_thumb_wrap">
            <div class="td_about_year text-uppercase td_fs_64 td_bold">EST 1995</div>
            <div class="td_about_thumb_1">
              <img src="{{ asset('assets/img/home_1/about_img_1.jpg') }}" alt="">
            </div>
            <div class="td_about_thumb_2">
              <img src="{{ asset('assets/img/home_1/about_img_2.jpg') }}" alt="">
            </div>
            <a href="https://www.youtube.com/embed/rRid6GCJtgc" class="td_circle_text td_center td_video_open">
              <svg width="15" height="19" viewBox="0 0 15 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14.086 8.63792C14.6603 9.03557 14.6603 9.88459 14.086 10.2822L2.54766 18.2711C1.88444 18.7303 0.978418 18.2557 0.978418 17.449L0.978418 1.47118C0.978418 0.664496 1.88444 0.189811 2.54767 0.649016L14.086 8.63792Z" fill="white"/>
              </svg>   
              <img src="{{ asset('assets/img/home_1/about_circle_text.svg') }}" alt="" class="">                 
            </a>
            <div class="td_circle_shape"></div>
          </div>
        </div>

        <div class="col-lg-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
          <div class="td_section_heading td_style_1 td_mb_30">
            <p class="td_section_subtitle_up td_fs_18 td_semibold td_spacing_1 td_mb_10 text-uppercase td_accent_color">About us</p>
            <h2 class="td_section_title td_fs_48 mb-0">The largest & Most Diverse Universities in the United Emirates</h2>
            <p class="td_section_subtitle td_fs_18 mb-0">Far far away, behind the word mountains, far from the Consonantia, there live the blind texts. Separated they marks grove right at the coast of the Semantics a large language ocean</p>
          </div>
          <div class="td_mb_40">
            <ul class="td_list td_style_5 td_mp_0">
              <li>
                <h3 class="td_fs_24 td_mb_8">Graduate Program</h3>
                <p class="td_fs_18 mb-0">Browse the Undergraduate Degrees</p>
              </li>
              <li>
                <h3 class="td_fs_24 td_mb_8">Undergraduate Program</h3>
                <p class="td_fs_18 mb-0">Browse the Undergraduate Degrees</p>
              </li>
            </ul>
          </div>
          <a href="courses-grid-view.html" class="td_btn td_style_1 td_radius_10 td_medium">
            <span class="td_btn_in td_white_color td_accent_bg">
              <span>More About</span>
              <svg width="19" height="20" viewBox="0 0 19 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.1575 4.34302L3.84375 15.6567" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                <path d="M15.157 11.4142C15.157 11.4142 16.0887 5.2748 15.157 4.34311C14.2253 3.41142 8.08594 4.34314 8.08594 4.34314" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
              </svg> 
            </span>             
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="td_height_120 td_height_lg_80"></div>
</section>
<!-- End About Section -->



<!-- Start Campus Life -->
<section class="td_accent_bg td_shape_section_1">
  <div class="td_shape_position_4 td_accent_color position-absolute">
    <svg width="37" height="40" viewBox="0 0 37 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g opacity="0.4">
        <rect y="12.3906" width="23.6182" height="31.0709" rx="1" transform="rotate(-30.4551 0 12.3906)" fill="white"/>
        <rect x="4" y="14.8125" width="18.5361" height="2.62207" rx="1.31104" transform="rotate(-30.4551 4 14.8125)" fill="currentColor"/>
        <rect x="7" y="19.8125" width="18.5361" height="2.62207" rx="1.31104" transform="rotate(-30.4551 7 19.8125)" fill="currentColor"/>
      </g>
    </svg>          
  </div>
  <div class="td_height_120 td_height_lg_80"></div>
  <div class="container">
    <div class="row td_gap_y_40">
      <div class="col-lg-5 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
        <div class="td_height_57 td_height_lg_0"></div>
        <div class="td_section_heading td_style_1">
          <h2 class="td_section_title td_fs_48 mb-0 td_white_color">Navigate</h2>
          <p class="td_section_subtitle td_fs_18 mb-0 td_white_color td_opacity_7">
            Far far away, behind the word mountains, far from the Consonantia, there live the blind texts. 
            Separated they marks grove right at the coast of the Semantics
          </p>
        </div>
        <div class="td_btn_box">
          <svg width="299" height="315" viewBox="0 0 299 315" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g opacity="0.75" clip-path="url(#clip0_34_2222)">
              <path d="M242.757 275.771C242.505 275.771 242.253 275.75 242.005 275.707C32.3684 239.98 0.342741 8.13005 0.0437414 5.79468C-0.108609 4.51176 0.22739 3.21754 0.9787 2.19335C1.73001 1.16916 2.8359 0.497795 4.05598 0.32519C5.27606 0.152585 6.5117 0.492693 7.4943 1.27158C8.4769 2.05047 9.12704 3.20518 9.3034 4.48471C9.59772 6.7514 40.7872 231.477 243.5 266.022C244.658 266.22 245.702 266.868 246.426 267.838C247.15 268.808 247.5 270.028 247.406 271.256C247.312 272.484 246.782 273.63 245.921 274.467C245.06 275.303 243.93 275.769 242.757 275.771Z" fill="white"/>
              <path d="M299.002 275.455C271.709 283.305 237.446 297.872 215.562 314.617L235.465 269.602L223.318 221.648C242.099 242.137 273.428 262.728 299.002 275.455Z" fill="white"/>
            </g>
            <defs>
              <clipPath id="clip0_34_2222">
                <rect width="299" height="314" fill="white" transform="translate(0 0.421875)"/>
              </clipPath>
            </defs>
          </svg>  
          <div class="td_btn_box_in">
            <a href="courses-grid-view.html" class="td_btn td_style_1 td_radius_10 td_medium td_fs_18">
              <span class="td_btn_in td_heading_color td_white_bg">
                <span>View All Program</span>
              </span>             
            </a> 
          </div>             
        </div>
      </div>

      <div class="col-lg-6 offset-lg-1">
        <div class="row">
          <div class="col-sm-6">
            <div class="td_card td_style_2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
              <a href="course-details.html" class="td_card_thumb d-block">
                <img src="{{ asset('assets/img/home_1/campur_life_1.jpg') }}" alt="" class="w-100">
              </a>
              <div class="td_card_info">
                <h2 class="td_card_title mb-0 td_fs_18 td_semibold td_white_color">
                  <a href="course-details.html">Campus Student Life</a>
                </h2>
                <a href="course-details.html" class="td_card_btn">
                  <svg width="23" height="24" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.564 4.70161L4.42188 18.8438" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18.5654 13.5341C18.5654 13.5341 19.7299 5.85989 18.5654 4.69528C17.4008 3.53067 9.72656 4.69531 9.72656 4.69531" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </div>
            </div>

            <div class="td_height_40 td_height_lg_30"></div>

            <div class="td_card td_style_2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
              <a href="course-details.html" class="td_card_thumb d-block">
                <img src="{{ asset('assets/img/home_1/campur_life_3.jpg') }}" alt="" class="w-100">
              </a>
              <div class="td_card_info">
                <h2 class="td_card_title mb-0 td_fs_18 td_semibold td_white_color">
                  <a href="course-details.html">Recreations & Wellness</a>
                </h2>
                <a href="course-details.html" class="td_card_btn">
                  <svg width="23" height="24" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.564 4.70161L4.42188 18.8438" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18.5654 13.5341C18.5654 13.5341 19.7299 5.85989 18.5654 4.69528C17.4008 3.53067 9.72656 4.69531 9.72656 4.69531" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>

          <div class="col-sm-6">
            <div class="td_height_50 td_height_lg_30"></div>
            <div class="td_card td_style_2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
              <a href="course-details.html" class="td_card_thumb d-block">
                <img src="{{ asset('assets/img/home_1/campur_life_2.jpg') }}" alt="" class="w-100">
              </a>
              <div class="td_card_info">
                <h2 class="td_card_title mb-0 td_fs_18 td_semibold td_white_color">
                  <a href="course-details.html">Arts & Cultural Program</a>
                </h2>
                <a href="course-details.html" class="td_card_btn">
                  <svg width="23" height="24" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.564 4.70161L4.42188 18.8438" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18.5654 13.5341C18.5654 13.5341 19.7299 5.85989 18.5654 4.69528C17.4008 3.53067 9.72656 4.69531 9.72656 4.69531" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </div>
            </div>

            <div class="td_height_40 td_height_lg_30"></div>

            <div class="td_card td_style_2 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
              <a href="course-details.html" class="td_card_thumb d-block">
                <img src="{{ asset('assets/img/home_1/campur_life_4.jpg') }}" alt="" class="w-100">
              </a>
              <div class="td_card_info">
                <h2 class="td_card_title mb-0 td_fs_18 td_semibold td_white_color">
                  <a href="course-details.html">Sports & Fitness</a>
                </h2>
                <a href="course-details.html" class="td_card_btn">
                  <svg width="23" height="24" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.564 4.70161L4.42188 18.8438" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18.5654 13.5341C18.5654 13.5341 19.7299 5.85989 18.5654 4.69528C17.4008 3.53067 9.72656 4.69531 9.72656 4.69531" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="td_height_112 td_height_lg_75"></div>
</section>
<!-- End Campus Life -->


    <!-- Start Departments Section -->
    <section>
      <div class="td_height_112 td_height_lg_75"></div>
      <div class="container">
        <div class="td_section_heading td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
          <p class="td_section_subtitle_up td_fs_18 td_semibold td_spacing_1 td_mb_10 text-uppercase td_accent_color">Departments</p>
          <h2 class="td_section_title td_fs_48 mb-0">Popular Departments</h2>
          <p class="td_section_subtitle td_fs_18 mb-0">Far far away, behind the word mountains, far from the Consonantia, there live <br>the blind texts. Separated they marks grove right at the coast</p>
        </div>
        <div class="td_height_50 td_height_lg_50"></div>
        <div class="td_iconbox_1_wrap">
          <div class="td_iconbox td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
            <div class="td_iconbox_icon td_accent_color td_mb_10">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_34_2239)">
                <path d="M86.126 63.5156H46.4883L74.5107 91.5381C75.7496 92.777 77.8014 92.666 78.8801 91.2854C84.4443 84.1625 87.9336 75.7453 89.0367 66.7844C89.2508 65.0453 87.8783 63.5156 86.126 63.5156Z" fill="#890C25"/>
                <path d="M37.3424 62.6603C36.793 62.1109 36.4842 61.3656 36.4842 60.5887V24.5742C36.4842 22.7795 34.8828 21.3922 33.1109 21.6781C14.3254 24.7105 -0.0588036 41.0676 0.00018075 60.709C0.0650245 82.3125 17.708 99.9478 39.3113 100.003C47.7394 100.024 55.7699 97.414 62.4678 92.5601C63.9219 91.5062 64.0768 89.3945 62.8068 88.1248L37.3424 62.6603Z" fill="#890C25"/>
                <path d="M99.985 54.4305C97.0867 25.7699 74.2301 2.9135 45.5695 0.0150621C43.841 -0.159743 42.3438 1.20959 42.3438 2.9469V57.6563H97.0531C98.7904 57.6563 100.16 56.159 99.985 54.4305Z" fill="#890C25"/>
                </g>
                <defs>
                <clipPath id="clip0_34_2239">
                <rect width="100" height="100" fill="white"/>
                </clipPath>
                </defs>
              </svg>                          
            </div>
            <h3 class="td_iconbox_title mb-0 td_medium td_fs_36">Economics</h3>
          </div>
          <div class="td_iconbox td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
            <div class="td_iconbox_icon td_accent_color td_mb_10">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_34_2246)">
                <path d="M50 26.5625C53.4518 26.5625 56.25 23.7643 56.25 20.3125C56.25 16.8607 53.4518 14.0625 50 14.0625C46.5482 14.0625 43.75 16.8607 43.75 20.3125C43.75 23.7643 46.5482 26.5625 50 26.5625Z" fill="#890C25"/>
                <path d="M84.375 34.375C86.9638 34.375 89.0625 32.2763 89.0625 29.6875C89.0625 27.0987 86.9638 25 84.375 25C81.7862 25 79.6875 27.0987 79.6875 29.6875C79.6875 32.2763 81.7862 34.375 84.375 34.375Z" fill="#890C25"/>
                <path d="M43.75 6.25H46.875V11.4844C48.8945 10.7552 51.1055 10.7552 53.125 11.4844V6.25H56.25C57.0788 6.25 57.8737 5.92076 58.4597 5.33471C59.0458 4.74866 59.375 3.9538 59.375 3.125C59.375 2.2962 59.0458 1.50134 58.4597 0.915291C57.8737 0.32924 57.0788 0 56.25 0L43.75 0C42.9212 0 42.1263 0.32924 41.5403 0.915291C40.9542 1.50134 40.625 2.2962 40.625 3.125C40.625 3.9538 40.9542 4.74866 41.5403 5.33471C42.1263 5.92076 42.9212 6.25 43.75 6.25Z" fill="#890C25"/>
                <path d="M32.8125 89.0625V90.625H67.1875V89.0625C67.1875 87.8193 66.6936 86.627 65.8146 85.7479C64.9355 84.8689 63.7432 84.375 62.5 84.375H37.5C36.2568 84.375 35.0645 84.8689 34.1854 85.7479C33.3064 86.627 32.8125 87.8193 32.8125 89.0625Z" fill="#890C25"/>
                <path d="M70.3125 93.75H29.6875C28.8587 93.75 28.0638 94.0792 27.4778 94.6653C26.8917 95.2513 26.5625 96.0462 26.5625 96.875V98.4375C26.5625 98.8519 26.7271 99.2493 27.0201 99.5424C27.3132 99.8354 27.7106 100 28.125 100H71.875C72.2894 100 72.6868 99.8354 72.9799 99.5424C73.2729 99.2493 73.4375 98.8519 73.4375 98.4375V96.875C73.4375 96.0462 73.1083 95.2513 72.5222 94.6653C71.9362 94.0792 71.1413 93.75 70.3125 93.75Z" fill="#890C25"/>
                <path d="M56.1133 27.4094L64.1352 31.9937C65.0799 32.533 66.1489 32.8168 67.2367 32.8172H77.2258C76.789 31.8333 76.5633 30.7687 76.5633 29.6922C76.5633 28.6157 76.789 27.5511 77.2258 26.5672H67.2367L59.2195 21.9844C58.8371 24.0955 57.7404 26.0109 56.1133 27.4094Z" fill="#890C25"/>
                <path d="M99.8438 58.7047L89.05 35.9062C88.2135 36.5409 87.2566 36.9986 86.2375 37.2516L96.7078 59.3734H72.0422L82.5203 37.2516C81.5012 36.9986 80.5443 36.5409 79.7078 35.9062L68.9062 58.7047C68.8048 58.9131 68.7514 59.1416 68.75 59.3734C68.75 63.5174 70.3962 67.4917 73.3265 70.422C76.2567 73.3522 80.231 74.9984 84.375 74.9984C88.519 74.9984 92.4933 73.3522 95.4235 70.422C98.3538 67.4917 100 63.5174 100 59.3734C99.9986 59.1416 99.9452 58.9131 99.8438 58.7047Z" fill="#890C25"/>
                <path d="M15.625 34.375C18.2138 34.375 20.3125 32.2763 20.3125 29.6875C20.3125 27.0987 18.2138 25 15.625 25C13.0362 25 10.9375 27.0987 10.9375 29.6875C10.9375 32.2763 13.0362 34.375 15.625 34.375Z" fill="#890C25"/>
                <path d="M31.25 59.3734C31.2486 59.1416 31.1952 58.9131 31.0938 58.7047L20.3 35.9062C19.4612 36.5419 18.5015 36.9996 17.4797 37.2516L27.9578 59.3734H3.29219L13.7703 37.2516C12.7485 36.9996 11.7888 36.5419 10.95 35.9062L0.15625 58.7047C0.0548166 58.9131 0.00142284 59.1416 0 59.3734C0 63.5174 1.6462 67.4917 4.57646 70.422C7.50671 73.3522 11.481 74.9984 15.625 74.9984C19.769 74.9984 23.7433 73.3522 26.6735 70.422C29.6038 67.4917 31.25 63.5174 31.25 59.3734Z" fill="#890C25"/>
                <path d="M32.7625 32.8172C33.8503 32.8168 34.9193 32.533 35.8641 31.9937L43.8859 27.4094C42.2589 26.0109 41.1621 24.0955 40.7797 21.9844L32.7625 26.5672H22.7734C23.2102 27.5511 23.4359 28.6157 23.4359 29.6922C23.4359 30.7687 23.2102 31.8333 22.7734 32.8172H32.7625Z" fill="#890C25"/>
                <path d="M46.875 29.1406V81.25H53.125V29.1406C51.1055 29.8698 48.8945 29.8698 46.875 29.1406Z" fill="#890C25"/>
                </g>
                <defs>
                <clipPath id="clip0_34_2246">
                <rect width="100" height="100" fill="white"/>
                </clipPath>
                </defs>
              </svg>                               
            </div>
            <h3 class="td_iconbox_title mb-0 td_medium td_fs_36">Economics</h3>
          </div>
          <div class="td_iconbox td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
            <div class="td_iconbox_icon td_accent_color td_mb_10">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_34_2260)">
                <path d="M5.48785 47.2141C5.57737 47.3052 5.7193 47.4286 5.90882 47.5794C7.61285 43.6278 10.187 38.6697 14.0782 33.4915C17.629 28.7665 21.2798 25.1826 24.3483 22.5665C22.0604 25.6036 19.3395 29.835 17.0838 35.2697C14.4927 41.5133 13.4266 47.1487 12.9693 51.2673C18.4435 53.1278 25.9903 53.5834 32.6137 46.8036C44.0548 35.0923 30.8709 20.0044 50.9693 6.50035C50.9693 6.50035 25.1346 -0.710944 8.64995 16.1616C-7.83634 33.0358 4.04753 45.7657 5.48785 47.2141Z" fill="#890C25"/>
                <path d="M87.7621 60.4129C87.7621 60.4129 105.67 40.1975 98.1581 17.6983C90.6476 -4.80005 74.1065 0.292695 72.1863 0.949953C72.0661 0.991082 71.8911 1.06528 71.6758 1.1685C74.5742 3.29834 79.9734 7.90076 83.4653 15.7096C85.5186 20.3008 86.2436 24.5072 86.5032 27.5016C84.3379 24.0201 81.2694 19.7741 77.0258 15.4701C72.8218 11.2064 68.6758 8.11447 65.2686 5.92495C61.1806 10.0604 57.404 16.704 60.4242 25.7443C65.6379 41.3604 84.8371 36.1419 87.7621 60.4129Z" fill="#890C25"/>
                <path d="M78.6168 75.7887C77.0144 70.1645 73.0934 63.6073 63.8281 61.9347C47.8241 59.0452 43.0814 78.6234 20.7031 69.529C20.7031 69.529 29.5394 95.1855 52.5967 99.35C75.6539 103.515 79.2249 86.3597 79.5805 84.3363C79.6023 84.2081 79.6233 84.0202 79.6378 83.7774C75.7031 85.0371 69.9459 86.3855 62.9241 86.3419C57.1023 86.3057 52.2249 85.3234 48.6459 84.3097C52.9322 84.1234 58.4757 83.4726 64.7039 81.6403C70.4007 79.9645 75.0684 77.7726 78.6168 75.7887Z" fill="#890C25"/>
                </g>
                <defs>
                <clipPath id="clip0_34_2260">
                <rect width="100" height="100" fill="white"/>
                </clipPath>
                </defs>
              </svg>                            
            </div>
            <h3 class="td_iconbox_title mb-0 td_medium td_fs_36">Economics</h3>
          </div>
          <div class="td_iconbox td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
            <div class="td_iconbox_icon td_accent_color td_mb_10">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.5625 21.875V57.8125H43.75V51.7812L60.9375 44.0781V37.4844L26.5625 21.875ZM40.625 42.1875H34.375V35.9375H40.625V42.1875Z" fill="#890C25"/>
                <path d="M6.25 60.9375V85.9375H43.75V60.9375H6.25ZM21.875 76.5625H15.625V70.3125H21.875V76.5625Z" fill="#890C25"/>
                <path d="M46.875 53.8125V85.9375H76.5625V70.3125H85.9375V85.9375H93.75V32.8125L46.875 53.8125ZM65.625 76.5625H59.375V70.3125H65.625V76.5625Z" fill="#890C25"/>
              </svg>                               
            </div>
            <h3 class="td_iconbox_title mb-0 td_medium td_fs_36">Economics</h3>
          </div>
        </div>
      </div>
      <div class="td_height_120 td_height_lg_80"></div>
    </section>
    <!-- End Departments Section -->



<!-- Start Video Section -->
<section>
  <div class="td_video_block td_style_1 td_accent_bg td_bg_filed td_center text-center" data-src="{{ asset('assets/img/home_1/video_bg.jpg') }}">
    <div class="container">
      <a href="https://www.youtube.com/embed/rRid6GCJtgc" class="td_player_btn_wrap_2 td_video_open wow zoomIn" data-wow-duration="1s" data-wow-delay="0.2s">
        <span class="td_player_btn td_center">
          <span></span>
        </span>
      </a>
      <div class="td_height_70 td_height_lg_50"></div>
      <h2 class="td_fs_48 td_white_color mb-0 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
        Take a Video Tour to Learn <br>Intro of Campus
      </h2>
    </div>
  </div>
  <div class="container wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
    <div class="td_contact_box td_style_1 td_accent_bg td_radius_10">
      <div class="td_contact_box_left">
        <p class="td_fs_18 td_light td_white_color td_mb_4">Get In Touch:</p>
        <h3 class="td_fs_36 mb-0 td_white_color"><a href="mailto:info@eduon.com">info@eduon.com</a></h3>
      </div>
      <div class="td_contact_box_or td_fs_24 td_medium td_white_bg td_center rounded-circle td_accent_color">
        or
      </div>
      <div class="td_contact_box_right">
        <p class="td_fs_18 td_light td_white_color td_mb_4">Get In Touch:</p>
        <h3 class="td_fs_36 mb-0 td_white_color"><a href="tel:+019987698870">+01 998 7698 870</a></h3>
      </div>
    </div>
  </div>
</section>
<!-- End Video Section -->



   <!-- Start Blog Section -->
<section>
  <div class="td_height_112 td_height_lg_75"></div>
  <div class="container">
    <div class="td_section_heading td_style_1 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
      <p class="td_section_subtitle_up td_fs_18 td_semibold td_spacing_1 td_mb_10 text-uppercase td_accent_color">BLOG & ARTICLES</p>
      <h2 class="td_section_title td_fs_48 mb-0">Take A Look At The Latest <br>Articles</h2>
    </div>
    <div class="td_height_50 td_height_lg_50"></div>
    <div class="row td_gap_y_30">
      
      <div class="col-lg-4 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s">
        <div class="td_post td_style_1">
          <a href="blog-details.html" class="td_post_thumb d-block">
            <img src="{{ asset('assets/img/home_1/post_1.jpg') }}" alt="">
            <i class="fa-solid fa-link"></i>
          </a>
          <div class="td_post_info">
            <div class="td_post_meta td_fs_14 td_medium td_mb_20">
              <span><img src="{{ asset('assets/img/icons/calendar.svg') }}" alt="">Jan 23 , 2024</span>
              <span><img src="{{ asset('assets/img/icons/user.svg') }}" alt="">Jhon Doe</span>
            </div>
            <h2 class="td_post_title td_fs_24 td_medium td_mb_16">
              <a href="blog-details.html">Comprehensive Student Guide for New Educations System</a>
            </h2>
            <p class="td_post_subtitle td_mb_24 td_heading_color td_opacity_7">Education is a dynamic and evolving field that plays a crucial.</p>
            <a href="blog-details.html" class="td_btn td_style_1 td_type_3 td_radius_30 td_medium">
              <span class="td_btn_in td_accent_color">
                <span>Read More</span>
              </span>             
            </a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
        <div class="td_post td_style_1">
          <a href="blog-details.html" class="td_post_thumb d-block">
            <img src="{{ asset('assets/img/home_1/post_2.jpg') }}" alt="">
            <i class="fa-solid fa-link"></i>
          </a>
          <div class="td_post_info">
            <div class="td_post_meta td_fs_14 td_medium td_mb_20">
              <span><img src="{{ asset('assets/img/icons/calendar.svg') }}" alt="">Jan 20 , 2024</span>
              <span><img src="{{ asset('assets/img/icons/user.svg') }}" alt="">Jhon Doe</span>
            </div>
            <h2 class="td_post_title td_fs_24 td_medium td_mb_16">
              <a href="blog-details.html">Overview of the New Education System for Students</a>
            </h2>
            <p class="td_post_subtitle td_mb_24 td_heading_color td_opacity_7">Education is a dynamic and evolving field that plays a crucial.</p>
            <a href="blog-details.html" class="td_btn td_style_1 td_type_3 td_radius_30 td_medium">
              <span class="td_btn_in td_accent_color">
                <span>Read More</span>
              </span>             
            </a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s">
        <div class="td_post td_style_1">
          <a href="blog-details.html" class="td_post_thumb d-block">
            <img src="{{ asset('assets/img/home_1/post_3.jpg') }}" alt="">
            <i class="fa-solid fa-link"></i>
          </a>
          <div class="td_post_info">
            <div class="td_post_meta td_fs_14 td_medium td_mb_20">
              <span><img src="{{ asset('assets/img/icons/calendar.svg') }}" alt="">Jan 18 , 2024</span>
              <span><img src="{{ asset('assets/img/icons/user.svg') }}" alt="">Jhon Doe</span>
            </div>
            <h2 class="td_post_title td_fs_24 td_medium td_mb_16">
              <a href="blog-details.html">Student Guide for the New Education System</a>
            </h2>
            <p class="td_post_subtitle td_mb_24 td_heading_color td_opacity_7">Education is a dynamic and evolving field that plays a crucial.</p>
            <a href="blog-details.html" class="td_btn td_style_1 td_type_3 td_radius_30 td_medium">
              <span class="td_btn_in td_accent_color">
                <span>Read More</span>
              </span>             
            </a>
          </div>
        </div>
      </div>

    </div>
  </div>
  <div class="td_height_120 td_height_lg_80"></div>
</section>
<!-- End Blog Section -->

 