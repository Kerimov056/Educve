@extends('layouts.app')

  <!-- Start Header Section -->
<header class="td_site_header td_style_1 td_type_2 td_sticky_header td_medium td_heading_color">
  <div class="td_top_header td_heading_bg td_white_color">
    <div class="container">
      <div class="td_top_header_in">
        <div class="td_top_header_left">
          <ul class="td_header_contact_list td_mp_0 td_normal">
            <li>
              <img src="{{ asset('assets/img/icons/call.svg') }}" alt="">
              <span>Call: <a href="tel:99066789768">990 66789 768</a></span>
            </li>
            <li>
              <img src="{{ asset('assets/img/icons/envlop.svg') }}" alt="">
              <span>Email: <a href="mailto:support@educat.com">support@educat.com</a></span>
            </li>
          </ul>
        </div>
        <div class="td_top_header_right">
          <span>
            <a href="signin.html">Login</a> / 
            <a href="signup.html">Register</a>
          </span>
          <a href="#" class="td_btn td_style_1 td_medium">
            <span class="td_btn_in td_white_color td_accent_bg">
              <span>Apply Now</span>
              <svg width="19" height="20" viewBox="0 0 19 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.1575 4.34302L3.84375 15.6567" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M15.157 11.4142C15.157 11.4142 16.0887 5.2748 15.157 4.34311C14.2253 3.41142 8.08594 4.34314 8.08594 4.34314" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg> 
            </span>             
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="td_main_header">
    <div class="container">
      <div class="td_main_header_in">
        <div class="td_main_header_left">
          <a class="td_site_branding td_accent_color" href="index.html">
            <svg width="142" height="50" viewBox="0 0 142 50" fill="none" xmlns="http://www.w3.org/2000/svg">
              <!-- SVG content -->
            </svg>
          </a>
          <div class="td_header_category_wrap position-relative">
            <button class="td_header_dropdown_btn td_medium td_heading_color">
              <img src="{{ asset('assets/img/icons/menu-square.svg') }}" alt="" class="td_header_dropdown_btn_icon">
              <span>All Category</span>
              <span class="td_header_dropdown_btn_tobble_icon td_center">
                <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 4.99997C9 4.99997 6.05404 1.00001 4.99997 1C3.94589 0.999991 1 5 1 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg> 
              </span>                 
            </button>
            <ul class="td_header_dropdown_list td_mp_0">
              <li><a href="courses-grid-view.html">Data Science</a></li>
              <li><a href="courses-grid-view.html">Design</a></li>
              <li><a href="courses-grid-with-sidebar.html">Development</a></li>
              <li><a href="courses-grid-view.html">Architecture</a></li>
              <li><a href="courses-grid-with-sidebar.html">Life Style</a></li>
              <li><a href="courses-grid-with-sidebar.html">Marketing</a></li>
              <li><a href="courses-grid-with-sidebar.html">Photography</a></li>
              <li><a href="courses-grid-with-sidebar.html">Motivation</a></li>
            </ul>
          </div>
        </div>

        <div class="td_main_header_right">
          <nav class="td_nav">
            <div class="td_nav_list_wrap">
              <div class="td_nav_list_wrap_in">
                <ul class="td_nav_list">
                  <li class="menu-item-has-children">
                    <a href="index.html">Home</a>
                    <ul>
                      <li><a href="index.html">University</a></li>
                      <li><a href="home-v2.html">Online Educations</a></li>
                      <li><a href="home-v3.html">Education</a></li>
                      <li><a href="home-v4.html">Kindergarten</a></li>
                      <li><a href="home-v5.html">Modern Language</a></li>
                      <li><a href="home-v6.html">Al-Quran Learning</a></li>
                      <li><a href="home-v7.html">Motivation Speaker</a></li>
                      <li><a href="home-v8.html">Kitchen Coach</a></li>
                    </ul>
                  </li>
                  <li class="menu-item-has-children">
                    <a href="products.html">Courses</a>
                    <ul>
                      <li><a href="courses-grid-view.html">Courses Grid View</a></li>
                      <li><a href="courses-list-view.html">Courses List View</a></li>
                      <li><a href="courses-grid-with-sidebar.html">Courses Grid With Sidebar</a></li>
                      <li><a href="course-details.html">Course Details</a></li>
                    </ul>
                  </li>
                  <li><a href="about.html">About</a></li>
                  <li class="menu-item-has-children td_mega_menu">
                    <a href="#">Pages</a>
                    <ul class="td_mega_wrapper">
                      <li class="menu-item-has-children">
                        <h4>Inner Pages</h4>
                        <ul>
                          <li><a href="event.html">Upcoming Event</a></li>
                          <li><a href="event-details.html">Event Details</a></li>
                          <li><a href="team-members.html">Team Members</a></li>
                          <li><a href="team-member-details.html">Team Details</a></li>
                        </ul>
                      </li>
                      <li class="menu-item-has-children">
                        <h4>Inner Pages</h4>
                        <ul>
                          <li><a href="students-registrations.html">Students Registrations</a></li>
                          <li><a href="instructor-registrations.html">Instructor Registrations</a></li>
                          <li><a href="signup.html">Signup</a></li>
                          <li><a href="signin.html">Signin</a></li>
                        </ul>
                      </li>
                      <li class="menu-item-has-children">
                        <h4>Shop Pages</h4>
                        <ul>
                          <li><a href="faqs.html">Faqs</a></li>
                          <li><a href="cart.html">Cart</a></li>
                          <li><a href="checkout.html">Checkout</a></li>
                          <li><a href="error.html">Error</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li class="menu-item-has-children">
                    <a href="#">Blogs</a>
                    <ul>
                      <li><a href="blog.html">Blogs</a></li>
                      <li><a href="blog-with-sidebar.html">Blog With Sidebar</a></li>
                      <li><a href="blog-details.html">Blog Details</a></li>
                    </ul>
                  </li>
                  <li><a href="contact.html">Contact</a></li>
                </ul>
              </div>
            </div>
          </nav>

          <div class="td_hero_icon_btns position-relative">
            <div class="position-relative">
              <button class="td_circle_btn td_center td_search_tobble_btn" type="button">
                <img src="{{ asset('assets/img/icons/search_2.svg') }}" alt="">                                     
              </button>
              <div class="td_header_search_wrap">
                <form action="#" class="td_header_search">
                  <input type="text" class="td_header_search_input" placeholder="Search For Anything">
                  <button class="td_header_search_btn td_center">
                    <img src="{{ asset('assets/img/icons/search_2.svg') }}" alt="">
                  </button>
                </form>
              </div>
            </div>
            <button class="td_circle_btn td_center td_wishlist_btn" type="button">
              <img src="{{ asset('assets/img/icons/love.svg') }}" alt="">
              <span class="td_circle_btn_label">0</span>
            </button>
            <button class="td_circle_btn td_center" type="button">
              <img src="{{ asset('assets/img/icons/cart.svg') }}" alt="">  
              <span class="td_circle_btn_label">0</span>                                                       
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- End Header Section -->


<!-- Start Page Heading Section -->
<section class="td_page_heading td_center td_bg_filed td_heading_bg text-center td_hobble" data-src="{{ asset('assets/img/others/page_heading_bg.jpg') }}">
  <div class="container">
    <div class="td_page_heading_in">
      <h1 class="td_white_color td_fs_48 td_mb_10">Course Details</h1>
      <ol class="breadcrumb m-0 td_fs_20 td_opacity_8 td_semibold td_white_color">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active">Course Details</li>
      </ol>
    </div>
  </div>
  <div class="td_page_heading_shape_1 position-absolute td_hover_layer_3"></div>
  <div class="td_page_heading_shape_2 position-absolute td_hover_layer_5"></div>
  <div class="td_page_heading_shape_3 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_3.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_4 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_4.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_5 position-absolute">
    <img src="{{ asset('assets/img/others/page_heading_shape_5.svg') }}" alt="">
  </div>
  <div class="td_page_heading_shape_6 position-absolute td_hover_layer_3"></div>
</section>
<!-- End Page Heading Section -->




    <!-- Start Course Details Section -->
    <section>
      <div class="td_height_120 td_height_lg_80"></div>
      <div class="container">
        <div class="row td_gap_y_50">
          <div class="col-lg-8">
            <div class="td_course_details">
              <div class="embed-responsive embed-responsive-16by9 td_radius_10 td_mb_40">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/_uQrJ0TkZlc" allowfullscreen></iframe>
              </div>
              <span class="td_course_label td_mb_10">Data Analytics</span>
              <h2 class="td_fs_48 td_mb_30">Starting Reputed Education & Build your Skills</h2>
              <div class="td_course_meta td_mb_40">
                <div class="td_course_avatar">
            <img src="{{ asset('assets/img/others/author_1.jpg') }}" alt="">

                  <p class="td_heading_color mb-0 td_medium"><span class="td_accent_color">Trainer:</span> <a href="#">Mathur Rahman</a></p>
                </div>
                <div class="td_course_published td_medium td_heading_color"><span class="td_accent_color">Last Update:</span> 24 July, 2024</div>
              </div>
              <div class="td_tabs td_style_1 td_mb_50">
                <ul class="td_tab_links td_style_2 td_type_2 td_mp_0 td_medium td_fs_20 td_heading_color">
                  <li class="active"><a href="#td_tab_1">Overview</a></li>
                  <li><a href="#td_tab_2">Curriculum</a></li>
                  <li><a href="#td_tab_3">Instructor</a></li>
                  <li><a href="#td_tab_4">Reviews</a></li>
                </ul>
                <div class="td_tab_body td_fs_18">
                  <div class="td_tab active" id="td_tab_1">
                    <h2 class="td_fs_48 td_mb_20">Courses Descriptions</h2>
                    <p class="mb-0">Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia-. That’s why we’ve developed close working relationships with a number of strategic partner. <br><br>When an unknown printer took a galley of type and scrambled it to make a type specimen bookhas a not only five centuries, but also the leap into electronic typesetting.</p>
                  </div>
                  <div class="td_tab" id="td_tab_2">
                    <h2 class="td_fs_48 td_mb_20">Courses Curriculum</h2>
                    <p class="mb-0">Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia-. That’s why we’ve developed close working relationships with a number of strategic partner. <br><br>When an unknown printer took a galley of type and scrambled it to make a type specimen bookhas a not only five centuries, but also the leap into electronic typesetting.</p>
                  </div>
                  <div class="td_tab" id="td_tab_3">
                    <h2 class="td_fs_48 td_mb_20">Courses Instructor</h2>
                    <p class="mb-0">Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia-. That’s why we’ve developed close working relationships with a number of strategic partner. <br><br>When an unknown printer took a galley of type and scrambled it to make a type specimen bookhas a not only five centuries, but also the leap into electronic typesetting.</p>
                  </div>
                  <div class="td_tab" id="td_tab_4">
                    <h2 class="td_fs_48 td_mb_20">Courses Reviews</h2>
                    <p class="mb-0">Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia-. That’s why we’ve developed close working relationships with a number of strategic partner. <br><br>When an unknown printer took a galley of type and scrambled it to make a type specimen bookhas a not only five centuries, but also the leap into electronic typesetting.</p>
                  </div>
                </div>
              </div>
              <h2 class="td_fs_48 td_mb_30">What you’ll Learn it?</h2>
              <ul class="td_list td_style_2 td_type_2 td_fs_18 td_medium td_heading_color td_mp_0">
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  100% Better results
                </li>
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  Building a Bright Future Together
                </li>
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  Budget Friendly Education Theme
                </li>
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  Empowering Children Through Education
                </li>
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  Unlocking Potential Educations
                </li>
                <li>
                  <svg class="td_accent_color" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="12" fill="currentColor"></circle>
                    <path d="M7.5 14.1136C7.5 14.1136 8.52273 14.1136 9.88636 16.5C9.88636 16.5 13.6765 10.25 17.0455 9" stroke="white" stroke-width="0.8" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                  Growing Genius Elementary School
                </li>
              </ul>
              <div class="td_height_60 td_height_lg_40"></div>
              <h4 class="td_fs_24 td_semibold td_mb_20">Requirements</h4>
              <div class="td_requirements_list td_medium td_fs_18">
                <span class="td_requirement">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.62323 2.73285C3.62323 2.6749 3.67039 2.62807 3.7283 2.62807H17.0304C17.0884 2.62807 17.1355 2.6749 17.1355 2.73285V11.761C17.1355 11.8189 17.0884 11.8657 17.0304 11.8657H10.2019V13.1891H17.0304C17.8182 13.1891 18.459 12.5484 18.459 11.761V2.73285C18.459 1.94541 17.8182 1.30469 17.0304 1.30469H3.72835C2.94061 1.30469 2.2998 1.94545 2.2998 2.73285V5.63045H3.62323V2.73285Z" fill="currentColor"/>
                    <path d="M19.4806 13.7344H10.2017V15.6143H18.6394C19.3908 15.6143 19.9998 15.0054 19.9998 14.2536C19.9998 13.9668 19.7674 13.7344 19.4806 13.7344Z" fill="currentColor"/>
                    <path d="M7.32878 6.95312H1.54968C0.695162 6.95312 0 7.6482 0 8.50276V17.1393C0 17.9938 0.695162 18.689 1.54968 18.689H7.32878C8.18334 18.689 8.87846 17.9938 8.87846 17.1393V8.50276C8.87846 7.6482 8.18334 6.95312 7.32878 6.95312ZM1.32342 8.50276C1.32342 8.37807 1.42486 8.2765 1.54968 8.2765H7.32878C7.45355 8.2765 7.55504 8.37803 7.55504 8.50276V16.5238H1.32342V8.50276ZM4.43912 18.0976C4.23018 18.0976 4.05435 17.9751 3.96533 17.8013C3.92774 17.728 3.90152 17.6481 3.90152 17.56C3.90152 17.263 4.14216 17.0224 4.43917 17.0224C4.73609 17.0224 4.97673 17.263 4.97673 17.56C4.97673 17.648 4.9506 17.728 4.91292 17.8013C4.82377 17.9751 4.64799 18.0976 4.43912 18.0976Z" fill="currentColor"/>
                  </svg>
                  Computer/ Mobile
                </span>
                <span class="td_requirement">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_34_14519)">
                    <path d="M19.4841 6.29402C18.7987 5.60863 17.6835 5.60867 16.9979 6.29418C16.7871 6.50523 15.4408 7.85262 15.2351 8.05848V3.41508C15.2351 2.94555 15.0523 2.50414 14.7202 2.17215L13.063 0.514844C12.731 0.182813 12.2896 0 11.82 0H1.75854C0.789287 0 0.000732422 0.788555 0.000732422 1.75781V18.2422C0.000732422 19.2114 0.789287 20 1.75854 20H13.4773C14.4466 20 15.2351 19.2114 15.2351 18.2422V13.0325L19.484 8.77996C20.171 8.09301 20.1712 6.98105 19.4841 6.29402ZM11.7195 1.17188C11.8302 1.17188 12.0435 1.1527 12.2344 1.34348L13.8916 3.00078C14.0776 3.18676 14.0633 3.39055 14.0633 3.51562H11.7195V1.17188ZM14.0632 18.2422C14.0632 18.5653 13.8004 18.8281 13.4773 18.8281H1.75854C1.43546 18.8281 1.17261 18.5653 1.17261 18.2422V1.75781C1.17261 1.43473 1.43546 1.17188 1.75854 1.17188H10.5476V4.10156C10.5476 4.42516 10.81 4.6875 11.1335 4.6875H14.0632V9.23137C14.0632 9.23137 12.3346 10.9615 12.3345 10.9616L11.5062 11.7898C11.4419 11.8541 11.3934 11.9326 11.3647 12.0189L10.536 14.5048C10.4658 14.7154 10.5206 14.9475 10.6776 15.1044C10.8347 15.2616 11.0669 15.3161 11.2772 15.246L13.7631 14.4173C13.8494 14.3886 13.9278 14.3401 13.9921 14.2758L14.0632 14.2047V18.2422ZM12.7492 12.2042L13.5778 13.0328L13.2613 13.3493L12.0183 13.7636L12.4326 12.5207L12.7492 12.2042ZM14.4063 12.204L13.5776 11.3754C14.0189 10.9338 15.9786 8.97234 16.3942 8.55637L17.2229 9.385L14.4063 12.204ZM18.6552 7.95148L18.0512 8.55602L17.2226 7.72738L17.8268 7.12266C18.0554 6.89418 18.427 6.89422 18.6555 7.12266C18.8839 7.35117 18.8851 7.7216 18.6552 7.95148Z" fill="currentColor"/>
                    <path d="M11.1335 5.85938H2.93042C2.60683 5.85938 2.34448 6.12172 2.34448 6.44531C2.34448 6.76891 2.60683 7.03125 2.93042 7.03125H11.1335C11.4571 7.03125 11.7195 6.76891 11.7195 6.44531C11.7195 6.12172 11.4571 5.85938 11.1335 5.85938Z" fill="currentColor"/>
                    <path d="M8.78979 8.20312H2.93042C2.60683 8.20312 2.34448 8.46547 2.34448 8.78906C2.34448 9.11266 2.60683 9.375 2.93042 9.375H8.78979C9.11339 9.375 9.37573 9.11266 9.37573 8.78906C9.37573 8.46547 9.11339 8.20312 8.78979 8.20312Z" fill="currentColor"/>
                    <path d="M8.78979 10.5469H2.93042C2.60683 10.5469 2.34448 10.8092 2.34448 11.1328C2.34448 11.4564 2.60683 11.7188 2.93042 11.7188H8.78979C9.11339 11.7188 9.37573 11.4564 9.37573 11.1328C9.37573 10.8092 9.11339 10.5469 8.78979 10.5469Z" fill="currentColor"/>
                    <path d="M8.78979 12.8906H2.93042C2.60683 12.8906 2.34448 13.153 2.34448 13.4766C2.34448 13.8002 2.60683 14.0625 2.93042 14.0625H8.78979C9.11339 14.0625 9.37573 13.8002 9.37573 13.4766C9.37573 13.153 9.11339 12.8906 8.78979 12.8906Z" fill="currentColor"/>
                    <path d="M11.1335 16.4844H7.61792C7.29433 16.4844 7.03198 16.7467 7.03198 17.0703C7.03198 17.3939 7.29433 17.6562 7.61792 17.6562H11.1335C11.4571 17.6562 11.7195 17.3939 11.7195 17.0703C11.7195 16.7467 11.4571 16.4844 11.1335 16.4844Z" fill="currentColor"/>
                    </g>
                    <defs>
                    <clipPath id="clip0_34_14519">
                    <rect width="20" height="20" fill="white"/>
                    </clipPath>
                    </defs>
                  </svg>                    
                  Paper/ Pencil
                </span>
                <span class="td_requirement">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18.3 7.59844C13.7 2.99844 6.3 2.99844 1.7 7.59844C1.3 7.99844 0.7 7.99844 0.3 7.59844C-0.1 7.19844 -0.1 6.59844 0.3 6.19844C5.7 0.798438 14.4 0.798438 19.7 6.19844C20.1 6.59844 20.1 7.19844 19.7 7.59844C19.3 7.99844 18.7 7.99844 18.3 7.59844Z" fill="currentColor"/>
                    <path d="M15.4 10.3984C12.4 7.49844 7.6 7.49844 4.7 10.3984C4.3 10.7984 3.7 10.7984 3.3 10.3984C2.9 9.99844 2.9 9.39844 3.3 8.99844C7 5.19844 13.1 5.19844 16.8 8.99844C17.2 9.39844 17.2 9.99844 16.8 10.3984C16.4 10.7984 15.8 10.7984 15.4 10.3984Z" fill="currentColor"/>
                    <path d="M12.6 13.3969C11.2 11.9969 9 11.9969 7.7 13.3969C7.3 13.7969 6.7 13.7969 6.3 13.3969C5.9 12.9969 5.9 12.2969 6.3 11.8969C8.4 9.59687 11.9 9.59687 14 11.8969C14.4 12.2969 14.4 12.9969 14 13.3969C13.6 13.7969 13 13.7969 12.6 13.3969Z" fill="currentColor"/>
                    <path d="M10.1002 17.9016C11.1495 17.9016 12.0002 17.0509 12.0002 16.0016C12.0002 14.9522 11.1495 14.1016 10.1002 14.1016C9.05085 14.1016 8.2002 14.9522 8.2002 16.0016C8.2002 17.0509 9.05085 17.9016 10.1002 17.9016Z" fill="currentColor"/>
                  </svg>                    
                  Internet Connect
                </span>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="td_card td_style_7">
              <a href="https://www.youtube.com/embed/rRid6GCJtgc" class="td_card_video_block td_video_open d-block">
             <img src="{{ asset('assets/img/others/video_thumb.jpg') }}" alt="">

                <span class="td_player_btn_wrap_2">
                  <span class="td_player_btn td_center">
                    <span></span>
                  </span>
                </span>
              </a>
              <div class="td_height_30 td_height_lg_30"></div>
              <h3 class="td_fs_20 td_semibold td_mb_15">Courses Includes:</h3>
              <ul class="td_card_list td_mp_0 td_fs_18 td_medium">
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <g clip-path="url(#clip0_34_14719)">
                      <path d="M22.9338 18.4587L19.1609 10.4029C19.0786 10.2271 18.8693 10.1514 18.6934 10.2337C18.5175 10.316 18.4417 10.5254 18.5241 10.7012L22.2969 18.7568C22.4657 19.1176 22.3095 19.5488 21.9487 19.7178L14.7151 23.1054C14.3544 23.2744 13.9234 23.1183 13.7543 22.7576L12.4019 19.8691L15.9219 11.3762C16.074 11.0091 16.0655 10.5919 15.8986 10.2314L13.9732 6.07225L16.469 6.86182C16.6611 6.92248 16.8201 7.06179 16.9054 7.24442L17.8298 9.21758C17.8896 9.34518 18.0163 9.42008 18.1485 9.42008C18.1984 9.42008 18.2491 9.40935 18.2974 9.3868C18.4732 9.30444 18.549 9.09505 18.4665 8.91922L17.5422 6.94638C17.374 6.58629 17.06 6.31108 16.6809 6.19136L13.671 5.23914C14.2916 4.33266 14.9452 3.12052 15.1701 2.57784C15.7599 1.15489 15.2839 0.363546 14.6418 0.0973879C13.9997 -0.168676 13.1035 0.0539344 12.5137 1.47688C12.26 2.08888 12.0273 3.42174 11.8618 4.56516C11.6648 4.5774 11.4668 4.61865 11.274 4.69238L6.72017 6.4323C6.35585 6.57152 6.06124 6.85802 5.9119 7.21826L1.04132 18.9701C0.895492 19.322 0.895398 19.7095 1.04109 20.0614C1.18673 20.4133 1.46071 20.6874 1.81251 20.8331L3.23705 21.4235C3.41644 21.4979 3.62218 21.4128 3.69648 21.2334C3.77082 21.054 3.6857 20.8483 3.5063 20.7739L2.08176 20.1835C1.9035 20.1096 1.76461 19.9707 1.69078 19.7924C1.61695 19.614 1.617 19.4176 1.69092 19.2393L6.56163 7.48732C6.63734 7.30474 6.78663 7.15952 6.97128 7.08898L11.5251 5.34906C11.6033 5.31915 11.6829 5.2975 11.7628 5.28339C11.7193 5.61362 11.6841 5.90242 11.6586 6.11889C11.5095 6.12742 11.3618 6.16422 11.2224 6.22947C10.9351 6.364 10.7173 6.60241 10.6093 6.90073C10.5013 7.19909 10.5159 7.52159 10.6504 7.80893C10.8521 8.23972 11.281 8.49294 11.728 8.49294C11.8964 8.49294 12.0675 8.45694 12.2299 8.38091C12.5172 8.24637 12.735 8.00792 12.843 7.70965C12.951 7.41129 12.9364 7.08879 12.8019 6.80144C12.7017 6.5875 12.5438 6.41228 12.3466 6.29205C12.3727 6.06817 12.4126 5.73803 12.4632 5.3537C12.7675 5.47229 13.0277 5.70344 13.174 6.01942L15.2605 10.5266C15.3451 10.7093 15.3493 10.9208 15.2722 11.1068L10.4048 22.8509C10.3309 23.0292 10.192 23.1681 10.0137 23.2419C9.83536 23.3158 9.63895 23.3157 9.46064 23.2418L5.11066 21.439C4.93136 21.3645 4.72558 21.4497 4.65123 21.6291C4.57694 21.8085 4.66201 22.0142 4.84141 22.0886L9.19138 23.8914C9.36928 23.9652 9.55382 24 9.73542 24C10.2951 24 10.8271 23.6685 11.0543 23.1201L12.0373 20.7487L13.1175 23.0558C13.3597 23.5727 13.8745 23.8767 14.4108 23.8767C14.613 23.8767 14.8184 23.8334 15.0133 23.7421L22.2469 20.3545C22.9587 20.0211 23.2668 19.1707 22.9338 18.4587ZM12.1818 7.47021C12.1378 7.5919 12.0489 7.68917 11.9317 7.7441C11.6897 7.85745 11.4006 7.75273 11.2872 7.51076C11.2323 7.39357 11.2264 7.26195 11.2704 7.14021C11.3145 7.01852 11.4033 6.92126 11.5206 6.86632C11.5859 6.83571 11.6557 6.82033 11.7258 6.82033C11.7814 6.82033 11.8372 6.83004 11.8911 6.84954C12.0128 6.8936 12.11 6.98243 12.165 7.09966C12.2199 7.21695 12.2259 7.34848 12.1818 7.47021ZM13.0677 4.87581C12.9101 4.77592 12.7394 4.69834 12.561 4.64513C12.7195 3.54792 12.937 2.29265 13.1635 1.74604C13.323 1.36105 13.7602 0.493203 14.3727 0.746939C14.9852 1.00082 14.6802 1.9236 14.5206 2.30854C14.3044 2.83017 13.667 4.00899 13.0677 4.87581Z" fill="currentColor"/>
                      <path d="M7.23809 11.8558C7.99982 11.4504 8.87385 11.3658 9.69923 11.6178C11.0692 12.0361 11.9888 13.2784 11.9874 14.7094C11.9873 14.9035 12.1445 15.0611 12.3387 15.0613C12.3388 15.0613 12.3389 15.0613 12.3391 15.0613C12.5331 15.0613 12.6905 14.9041 12.6907 14.71C12.6914 13.8844 12.4229 13.0604 11.9345 12.3897C11.4294 11.696 10.7274 11.1965 9.9045 10.9452C7.82985 10.3119 5.62685 11.4845 4.99361 13.559C4.68681 14.564 4.78975 15.6283 5.28349 16.5559C5.77718 17.4834 6.60246 18.1632 7.60742 18.47C7.98303 18.5847 8.37018 18.6416 8.75662 18.6416C9.30614 18.6416 9.85383 18.5264 10.363 18.2983C11.2216 17.9136 11.9142 17.2353 12.3132 16.3883C12.396 16.2127 12.3206 16.0032 12.145 15.9204C11.9694 15.8376 11.7598 15.913 11.6771 16.0886C10.9989 17.5283 9.33773 18.263 7.81283 17.7974C6.9875 17.5455 6.30973 16.9872 5.90426 16.2255C5.49883 15.4638 5.41427 14.5897 5.66627 13.7644C5.91808 12.9391 6.47642 12.2613 7.23809 11.8558Z" fill="currentColor"/>
                      <path d="M10.1082 13.7475C10.0241 13.5893 9.88337 13.4733 9.71195 13.4211L9.55225 13.3723L9.66076 13.0168C9.71743 12.8311 9.61286 12.6345 9.42718 12.5779C9.24137 12.5213 9.04496 12.6258 8.98824 12.8114L8.87729 13.175C8.40886 13.0942 7.94105 13.3724 7.79878 13.8386C7.72406 14.0834 7.74914 14.3426 7.86938 14.5684C7.98956 14.7943 8.19061 14.9599 8.4353 15.0346L8.8779 15.1697C8.94301 15.1895 8.99645 15.2335 9.02841 15.2936C9.06038 15.3537 9.06704 15.4226 9.04717 15.4877C9.02729 15.5528 8.98327 15.6062 8.92318 15.6382C8.86313 15.6702 8.79423 15.6769 8.72912 15.657L8.50786 15.5894L8.04146 15.4471C8.07807 15.2711 7.97503 15.0931 7.79977 15.0396C7.61395 14.983 7.4175 15.0875 7.36083 15.2732C7.25287 15.6269 7.45275 16.0025 7.80652 16.1106L7.96627 16.1593L7.85775 16.5148C7.80108 16.7006 7.90566 16.8971 8.09133 16.9538C8.12555 16.9642 8.1601 16.9692 8.19408 16.9692C8.34465 16.9692 8.48401 16.8717 8.53027 16.7201L8.64113 16.357C8.69551 16.3664 8.75016 16.3717 8.80473 16.3717C8.95956 16.3717 9.11307 16.3338 9.2536 16.2589C9.47945 16.1388 9.64506 15.9377 9.71973 15.693C9.87395 15.1878 9.58843 14.6513 9.08321 14.4971L8.64062 14.362C8.57555 14.3421 8.52211 14.2981 8.49015 14.238C8.45818 14.178 8.45147 14.109 8.4714 14.0439C8.51236 13.9096 8.65496 13.8335 8.78949 13.8746L9.0106 13.9421L9.01074 13.9422H9.01084L9.4771 14.0845C9.4405 14.2604 9.54353 14.4385 9.71879 14.492C9.90451 14.5486 10.1011 14.4441 10.1577 14.2583C10.21 14.0871 10.1924 13.9056 10.1082 13.7475Z" fill="currentColor"/>
                      <path d="M20.6055 18.4368L18.3553 13.6551C18.2726 13.4794 18.063 13.404 17.8875 13.4867C17.7118 13.5694 17.6364 13.7789 17.7191 13.9545L19.9693 18.7362C20.0292 18.8635 20.1557 18.9382 20.2877 18.9382C20.3378 18.9382 20.3888 18.9274 20.4371 18.9046C20.6128 18.822 20.6882 18.6125 20.6055 18.4368Z" fill="currentColor"/>
                      <path d="M19.0333 19.2806L16.7831 14.4989C16.7004 14.3231 16.4908 14.2477 16.3153 14.3304C16.1396 14.4131 16.0641 14.6226 16.1468 14.7982L18.397 19.5799C18.4569 19.7073 18.5834 19.7819 18.7154 19.7819C18.7656 19.7819 18.8165 19.7712 18.8648 19.7484C19.0405 19.6657 19.1159 19.4562 19.0333 19.2806Z" fill="currentColor"/>
                      </g>
                      <defs>
                      <clipPath id="clip0_34_14719">
                      <rect width="24" height="24" fill="white"/>
                      </clipPath>
                      </defs>
                    </svg>                      
                    Price :
                  </span>
                  <span class="td_semibold td_accent_color">$69</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12.1499 12.7396H11.9504C11.0609 12.7396 10.3364 12.0151 10.3364 11.1256C10.3364 10.9261 10.4984 10.7656 10.6964 10.7656H13.4024C13.6019 10.7656 13.7624 10.9276 13.7624 11.1256C13.7639 12.0151 13.0394 12.7396 12.1499 12.7396ZM11.1344 11.4856C11.2739 11.7991 11.5874 12.0196 11.9519 12.0196H12.1499C12.5144 12.0196 12.8294 11.8006 12.9674 11.4856H11.1344Z" fill="currentColor"/>
                      <path d="M10.3919 10.341C9.60894 10.341 8.97144 9.7035 8.97144 8.9205C8.97144 8.1375 9.60894 7.5 10.3919 7.5C11.1749 7.5 11.8124 8.1375 11.8124 8.9205C11.8124 9.7035 11.1749 10.341 10.3919 10.341ZM10.3919 8.22C10.0049 8.22 9.69144 8.535 9.69144 8.9205C9.69144 9.3075 10.0064 9.621 10.3919 9.621C10.7774 9.621 11.0924 9.306 11.0924 8.9205C11.0924 8.535 10.7774 8.22 10.3919 8.22Z" fill="currentColor"/>
                      <path d="M13.7159 10.341C12.9329 10.341 12.2954 9.7035 12.2954 8.9205C12.2954 8.1375 12.9329 7.5 13.7159 7.5C14.4989 7.5 15.1364 8.1375 15.1364 8.9205C15.1364 9.7035 14.4989 10.341 13.7159 10.341ZM13.7159 8.22C13.3289 8.22 13.0154 8.535 13.0154 8.9205C13.0154 9.3075 13.3289 9.621 13.7159 9.621C14.1029 9.621 14.4164 9.306 14.4164 8.9205C14.4164 8.535 14.1029 8.22 13.7159 8.22Z" fill="currentColor"/>
                      <path d="M12.6555 9.2825H11.4525C11.253 9.2825 11.0925 9.1205 11.0925 8.9225C11.0925 8.7245 11.2545 8.5625 11.4525 8.5625H12.6555C12.855 8.5625 13.0155 8.7245 13.0155 8.9225C13.0155 9.1205 12.855 9.2825 12.6555 9.2825Z" fill="currentColor"/>
                      <path d="M9.33148 9.2816C9.30598 9.2816 9.28048 9.2786 9.25498 9.2741L8.02348 9.0086C7.82848 8.9666 7.70548 8.7746 7.74748 8.5811C7.78948 8.3861 7.98148 8.2631 8.17498 8.3051L9.40648 8.5706C9.60148 8.6126 9.72448 8.8046 9.68248 8.9981C9.64648 9.1661 9.49798 9.2816 9.33148 9.2816Z" fill="currentColor"/>
                      <path d="M14.7767 9.2816C14.6102 9.2816 14.4617 9.1661 14.4257 8.9981C14.3837 8.8031 14.5067 8.6126 14.7017 8.5706L15.9287 8.3051C16.1237 8.2631 16.3142 8.3861 16.3562 8.5811C16.3982 8.7761 16.2752 8.9666 16.0802 9.0086L14.8532 9.2741C14.8277 9.2786 14.8022 9.2816 14.7767 9.2816Z" fill="currentColor"/>
                      <path d="M17.1841 9.64931C17.1706 9.64931 17.1571 9.64931 17.1436 9.64631C16.9456 9.62381 16.8046 9.44531 16.8256 9.24881C16.8526 9.01631 16.8661 8.77781 16.8661 8.53931C16.8661 6.46931 15.8641 4.59431 14.2501 3.64631C13.5661 3.24431 12.8266 3.04031 12.0511 3.04031C11.2756 3.04031 10.5361 3.24431 9.85211 3.64631C8.23811 4.59431 7.23611 6.46931 7.23611 8.53931C7.23611 8.77631 7.24961 9.01481 7.27661 9.24881C7.29911 9.44681 7.15661 9.62531 6.95861 9.64631C6.76061 9.66881 6.58211 9.52631 6.56111 9.32831C6.53111 9.06881 6.51611 8.80331 6.51611 8.53931C6.51611 7.38581 6.79961 6.25931 7.33511 5.28131C7.85861 4.32431 8.60411 3.54431 9.48761 3.02531C10.2721 2.56331 11.1586 2.32031 12.0511 2.32031C12.9436 2.32031 13.8301 2.56481 14.6146 3.02531C15.4981 3.54431 16.2436 4.32581 16.7671 5.28131C17.3026 6.25931 17.5861 7.38581 17.5861 8.53931C17.5861 8.80331 17.5711 9.06881 17.5426 9.32831C17.5201 9.51281 17.3656 9.64931 17.1841 9.64931Z" fill="currentColor"/>
                      <path d="M14.7856 3.40344L14.0776 3.27444V3.27594C14.0791 3.27144 14.1541 2.82294 13.9996 2.35044C13.8046 1.75494 13.3306 1.38444 12.5896 1.24644C12.2326 1.18044 11.8711 1.18044 11.5156 1.24644C10.7746 1.38444 10.2991 1.75494 10.1056 2.35044C9.95109 2.82294 10.0261 3.27144 10.0276 3.27594L9.67359 3.33894L9.31959 3.40344C9.31509 3.37944 9.21309 2.79744 9.41259 2.15844C9.60309 1.55094 10.0981 0.778437 11.3866 0.538437C11.8306 0.455938 12.2806 0.455938 12.7246 0.538437C14.0116 0.776937 14.5081 1.55094 14.6986 2.15844C14.8921 2.79744 14.7901 3.37944 14.7856 3.40344Z" fill="currentColor"/>
                      <path d="M16.2122 11.0621C16.0562 11.0621 15.9032 11.0366 15.7577 10.9871C15.5702 10.9226 15.4697 10.7171 15.5342 10.5296C15.5987 10.3421 15.8042 10.2416 15.9917 10.3061C16.0622 10.3301 16.1372 10.3421 16.2122 10.3421C16.3982 10.3421 16.5722 10.2671 16.7012 10.1336C16.8302 9.99861 16.8962 9.82161 16.8887 9.63411C16.8857 9.56211 16.8707 9.49161 16.8452 9.42411C16.7492 9.17511 16.5167 9.00411 16.2527 8.98761C16.1957 8.98461 16.1372 8.98761 16.0817 8.99961C15.8867 9.03711 15.6977 8.91111 15.6587 8.71461C15.6197 8.51811 15.7472 8.33061 15.9422 8.29161C16.0577 8.26911 16.1762 8.26161 16.2932 8.26761C16.8392 8.29911 17.3192 8.65161 17.5172 9.16461C17.5712 9.30411 17.6012 9.45111 17.6072 9.60111C17.6237 9.98661 17.4857 10.3511 17.2202 10.6286C16.9562 10.9091 16.5977 11.0621 16.2122 11.0621Z" fill="currentColor"/>
                      <path d="M7.88855 11.0627C7.50455 11.0627 7.14605 10.9097 6.87905 10.6322C6.61355 10.3547 6.47555 9.98872 6.49205 9.60322C6.49805 9.45322 6.52955 9.30622 6.58205 9.16522C6.77855 8.65222 7.25855 8.29972 7.80455 8.26822C7.92305 8.26072 8.04155 8.26972 8.15555 8.29222C8.35055 8.32972 8.47805 8.52022 8.44055 8.71522C8.40305 8.91022 8.21255 9.03772 8.01755 9.00022C7.96055 8.98972 7.90355 8.98522 7.84505 8.98822C7.58105 9.00322 7.34855 9.17422 7.25255 9.42472C7.22705 9.49222 7.21205 9.56272 7.20905 9.63472C7.20155 9.82222 7.26755 9.99922 7.39655 10.1342C7.52555 10.2692 7.69955 10.3427 7.88555 10.3427C7.96055 10.3427 8.03555 10.3307 8.10605 10.3067C8.29355 10.2422 8.49905 10.3412 8.56355 10.5302C8.62805 10.7192 8.52905 10.9232 8.34005 10.9877C8.19755 11.0372 8.04455 11.0627 7.88855 11.0627Z" fill="currentColor"/>
                      <path d="M12.0513 14.3284C11.4558 14.3284 10.8783 14.1919 10.3353 13.9219C9.81485 13.6639 9.34985 13.2949 8.95085 12.8269C8.14085 11.8744 7.69385 10.6129 7.69385 9.27338C7.69385 8.98388 7.71485 8.69288 7.75685 8.41088C7.85285 7.75838 8.14685 7.16288 8.58485 6.73238C9.03335 6.28988 9.60635 6.04688 10.1988 6.04688H13.9053C14.4963 6.04688 15.0708 6.28988 15.5193 6.73238C15.9558 7.16288 16.2498 7.75838 16.3473 8.41088C16.3893 8.69438 16.4103 8.98388 16.4103 9.27338C16.4103 10.6129 15.9633 11.8759 15.1533 12.8269C14.7543 13.2949 14.2878 13.6639 13.7688 13.9219C13.2243 14.1919 12.6468 14.3284 12.0513 14.3284ZM10.1973 6.76688C9.34535 6.76688 8.61935 7.50188 8.46785 8.51588C8.43035 8.76338 8.41235 9.01838 8.41235 9.27338C8.41235 11.6644 10.0443 13.6084 12.0498 13.6084C14.0553 13.6084 15.6873 11.6629 15.6873 9.27338C15.6873 9.01838 15.6693 8.76488 15.6318 8.51588C15.4818 7.50188 14.7543 6.76688 13.9023 6.76688H10.1973Z" fill="currentColor"/>
                      <path d="M12.5239 23.5234C12.4909 23.5234 12.4579 23.5189 12.4249 23.5099C12.2329 23.4559 12.1219 23.2564 12.1774 23.0644L14.4199 15.1759C14.4739 14.9839 14.6734 14.8729 14.8654 14.9284C15.0574 14.9824 15.1684 15.1819 15.1129 15.3739L12.8704 23.2639C12.8254 23.4199 12.6814 23.5234 12.5239 23.5234Z" fill="currentColor"/>
                      <path d="M11.4904 23.5169C11.3329 23.5169 11.1889 23.4134 11.1439 23.2559L8.90135 15.3659C8.84735 15.1739 8.95835 14.9759 9.14885 14.9204C9.33935 14.8649 9.53885 14.9774 9.59435 15.1679L11.8368 23.0564C11.8908 23.2484 11.7798 23.4464 11.5893 23.5019C11.5563 23.5124 11.5234 23.5169 11.4904 23.5169Z" fill="currentColor"/>
                      <path d="M10.5527 23.5196C10.4402 23.5196 10.3277 23.4671 10.2587 23.3666L8.08972 20.2886C8.00422 20.1671 8.00272 20.0051 8.08522 19.8806L8.78572 18.8381L7.74172 17.7791C7.65022 17.6861 7.61572 17.5511 7.65172 17.4266L8.32972 15.0806C8.38522 14.8901 8.58472 14.7791 8.77522 14.8346C8.96572 14.8901 9.07672 15.0896 9.02122 15.2801L8.40022 17.4236L9.50272 18.5426C9.62272 18.6641 9.64072 18.8546 9.54472 18.9956L8.81872 20.0771L10.8452 22.9526C10.9592 23.1146 10.9202 23.3396 10.7582 23.4536C10.6967 23.4986 10.6247 23.5196 10.5527 23.5196Z" fill="currentColor"/>
                      <path d="M13.4477 23.5181C13.3757 23.5181 13.3037 23.4971 13.2407 23.4521C13.0787 23.3381 13.0397 23.1131 13.1537 22.9511L15.1802 20.0756L14.4542 18.9941C14.3582 18.8516 14.3762 18.6626 14.4962 18.5411L15.5987 17.4221L14.9792 15.2801C14.9237 15.0896 15.0347 14.8901 15.2252 14.8346C15.4157 14.7791 15.6152 14.8901 15.6707 15.0806L16.3487 17.4266C16.3847 17.5511 16.3502 17.6861 16.2587 17.7791L15.2147 18.8381L15.9152 19.8806C15.9977 20.0051 15.9962 20.1671 15.9107 20.2886L13.7417 23.3666C13.6727 23.4656 13.5617 23.5181 13.4477 23.5181Z" fill="currentColor"/>
                      <path d="M14.1918 17.595H9.80727C9.60777 17.595 9.44727 17.433 9.44727 17.235C9.44727 17.037 9.60927 16.875 9.80727 16.875H14.1918C14.3913 16.875 14.5518 17.037 14.5518 17.235C14.5518 17.433 14.3898 17.595 14.1918 17.595Z" fill="currentColor"/>
                      <path d="M19.8137 23.5163H4.18666C3.98716 23.5163 3.82666 23.3543 3.82666 23.1563V20.3468C3.82666 19.6718 3.94666 19.0103 4.18216 18.3818C4.41016 17.7758 4.73866 17.2163 5.16016 16.7198C6.00916 15.7208 7.18216 15.0443 8.46616 14.8133C8.92366 14.7308 9.34516 14.5103 9.68416 14.1758L10.4387 13.4318C10.5797 13.2923 10.8077 13.2938 10.9472 13.4348C11.0867 13.5758 11.0852 13.8038 10.9442 13.9433L10.1897 14.6873C9.74716 15.1253 9.19366 15.4133 8.59216 15.5213C6.24766 15.9413 4.54666 17.9708 4.54666 20.3453V22.7963H19.4537V20.3468C19.4537 17.9558 17.7467 15.9263 15.3962 15.5183C14.7737 15.4103 14.2067 15.1163 13.7567 14.6663L13.0697 13.9793C12.9287 13.8383 12.9287 13.6103 13.0697 13.4708C13.2107 13.3313 13.4387 13.3298 13.5782 13.4708L14.2652 14.1563C14.6102 14.5013 15.0422 14.7263 15.5177 14.8088C16.8062 15.0323 17.9852 15.7073 18.8372 16.7093C19.2602 17.2073 19.5902 17.7668 19.8167 18.3758C20.0522 19.0058 20.1722 19.6688 20.1722 20.3468V23.1563C20.1737 23.3558 20.0117 23.5163 19.8137 23.5163Z" fill="currentColor"/>
                    </svg>                      
                    Instructor :
                  </span>
                  <span class="td_semibold td_accent_color">John Siro</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M18.5446 6.01555V1.67875H19.6798C19.8071 1.67875 19.9292 1.62818 20.0193 1.53816C20.1093 1.44814 20.1598 1.32605 20.1598 1.19875C20.1598 1.07145 20.1093 0.949356 20.0193 0.859339C19.9292 0.769321 19.8071 0.71875 19.6798 0.71875H4.31984C4.19254 0.71875 4.07045 0.769321 3.98043 0.859339C3.89042 0.949356 3.83984 1.07145 3.83984 1.19875C3.83984 1.32605 3.89042 1.44814 3.98043 1.53816C4.07045 1.62818 4.19254 1.67875 4.31984 1.67875H5.46464V6.01555C5.46464 8.23075 7.70384 10.4436 9.78464 12.0155C7.70144 13.5899 5.46464 15.8003 5.46464 18.0155V22.3188H4.31984C4.19254 22.3188 4.07045 22.3693 3.98043 22.4593C3.89042 22.5494 3.83984 22.6714 3.83984 22.7987C3.83984 22.9261 3.89042 23.0481 3.98043 23.1382C4.07045 23.2282 4.19254 23.2787 4.31984 23.2787H19.6798C19.8071 23.2787 19.9292 23.2282 20.0193 23.1382C20.1093 23.0481 20.1598 22.9261 20.1598 22.7987C20.1598 22.6714 20.1093 22.5494 20.0193 22.4593C19.9292 22.3693 19.8071 22.3188 19.6798 22.3188H18.5446V18.0299C18.5446 15.8075 16.3054 13.5971 14.2246 12.03C16.3054 10.4436 18.5446 8.23075 18.5446 6.01555ZM13.1326 11.6339C13.0706 11.6781 13.02 11.7364 12.9849 11.804C12.9499 11.8716 12.9314 11.9466 12.931 12.0227C12.931 12.0993 12.9493 12.1748 12.9844 12.2428C13.0194 12.3109 13.0703 12.3695 13.1326 12.4139C15.9622 14.4419 17.5846 16.4939 17.5846 18.0299V22.3188H6.41504V18.0299C6.41504 16.4891 8.03744 14.4419 10.867 12.4139C10.929 12.3695 10.9794 12.311 11.0143 12.2431C11.0491 12.1753 11.0672 12.1002 11.0672 12.0239C11.0672 11.9477 11.0491 11.8726 11.0143 11.8048C10.9794 11.7369 10.929 11.6784 10.867 11.6339C8.03744 9.59875 6.41504 7.55155 6.41504 6.01555V1.67875H17.5846V6.01555C17.5846 7.55155 15.9622 9.59875 13.1326 11.6339Z" fill="currentColor"/>
                      <path d="M12.2784 15.4727C12.1969 15.4142 12.0991 15.3828 11.9988 15.3828C11.8985 15.3828 11.8008 15.4142 11.7192 15.4727L11.5656 15.5831C9.16563 17.3039 7.61523 19.1255 7.61523 20.2247V20.6375C7.61523 20.7648 7.66581 20.8868 7.75582 20.9769C7.84584 21.0669 7.96793 21.1175 8.09523 21.1175H15.9048C16.0321 21.1175 16.1542 21.0669 16.2442 20.9769C16.3343 20.8868 16.3848 20.7648 16.3848 20.6375V20.2247C16.3848 19.1255 14.8344 17.3039 12.4344 15.5831L12.2784 15.4727ZM15.42 20.1575H8.58003C8.65683 19.6607 9.54003 18.2375 12 16.4543C14.4624 18.2375 15.3408 19.6607 15.42 20.1575Z" fill="currentColor"/>
                      <path d="M15.9048 4.57812H8.09523C7.96793 4.57812 7.84584 4.6287 7.75582 4.71871C7.66581 4.80873 7.61523 4.93082 7.61523 5.05812V6.01812C7.61523 7.12932 9.12963 8.89812 11.568 10.6621L11.7192 10.7701C11.801 10.8291 11.8992 10.8608 12 10.8608C12.1008 10.8608 12.1991 10.8291 12.2808 10.7701L12.432 10.6621C14.88 8.90772 16.3848 7.12932 16.3848 6.01812V5.05812C16.3848 4.93082 16.3343 4.80873 16.2442 4.71871C16.1542 4.6287 16.0321 4.57812 15.9048 4.57812ZM15.4248 6.01812C15.4248 6.51732 14.4912 7.97172 12 9.78852C9.50643 7.97172 8.57523 6.51732 8.57523 6.01812V5.53812H15.4248V6.01812Z" fill="currentColor"/>
                      <path d="M12 12.9301C12.1273 12.9301 12.2494 12.8796 12.3394 12.7895C12.4294 12.6995 12.48 12.5774 12.48 12.4501V12.1909C12.48 12.0636 12.4294 11.9415 12.3394 11.8515C12.2494 11.7615 12.1273 11.7109 12 11.7109C11.8727 11.7109 11.7506 11.7615 11.6606 11.8515C11.5706 11.9415 11.52 12.0636 11.52 12.1909V12.4501C11.52 12.5774 11.5706 12.6995 11.6606 12.7895C11.7506 12.8796 11.8727 12.9301 12 12.9301Z" fill="currentColor"/>
                      <path d="M11.52 14.2861C11.52 14.4134 11.5706 14.5355 11.6606 14.6255C11.7506 14.7155 11.8727 14.7661 12 14.7661C12.1273 14.7661 12.2494 14.7155 12.3394 14.6255C12.4294 14.5355 12.48 14.4134 12.48 14.2861V14.0269C12.48 13.8996 12.4294 13.7775 12.3394 13.6875C12.2494 13.5974 12.1273 13.5469 12 13.5469C11.8727 13.5469 11.7506 13.5974 11.6606 13.6875C11.5706 13.7775 11.52 13.8996 11.52 14.0269V14.2861Z" fill="currentColor"/>
                    </svg>                      
                    Durations :
                  </span>
                  <span class="td_semibold td_accent_color">15 Weeks</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M20.6926 4.25056C20.2951 4.16806 19.8976 4.11556 19.5001 4.04806V3.64306C19.4999 3.35082 19.4376 3.06195 19.3174 2.79559C19.1971 2.52923 19.0217 2.29147 18.8026 2.09806C18.5791 1.90185 18.3163 1.75554 18.0318 1.6689C17.7472 1.58225 17.4475 1.55725 17.1526 1.59556C15.1899 1.8282 13.3688 2.73478 12.0001 4.16056C10.6314 2.73478 8.81025 1.8282 6.84757 1.59556C6.55263 1.55725 6.25291 1.58225 5.96839 1.6689C5.68387 1.75554 5.42109 1.90185 5.19757 2.09806C4.97849 2.29147 4.80301 2.52923 4.68276 2.79559C4.56251 3.06195 4.50024 3.35082 4.50007 3.64306V4.04806C4.10257 4.11556 3.70507 4.16806 3.30757 4.25056C2.79797 4.35278 2.33948 4.62827 2.00999 5.03022C1.68049 5.43218 1.50032 5.93581 1.50007 6.45556V19.1606C1.49753 19.4801 1.5631 19.7966 1.69243 20.0889C1.82175 20.3811 2.01185 20.6425 2.25007 20.8556C2.49145 21.0656 2.77486 21.2218 3.08137 21.3136C3.38789 21.4054 3.71046 21.4308 4.02757 21.3881C6.62806 21.0375 9.27492 21.4005 11.6851 22.4381C11.7776 22.4773 11.8771 22.4974 11.9776 22.4974C12.0781 22.4974 12.1775 22.4773 12.2701 22.4381C14.6802 21.4005 17.3271 21.0375 19.9276 21.3881C20.2472 21.4311 20.5724 21.4049 20.881 21.3112C21.1896 21.2176 21.4745 21.0587 21.7163 20.8453C21.9581 20.6319 22.1513 20.369 22.2826 20.0745C22.414 19.7799 22.4805 19.4606 22.4776 19.1381V6.45556C22.4784 5.93896 22.3014 5.43782 21.9764 5.03629C21.6513 4.63477 21.198 4.35732 20.6926 4.25056ZM17.3476 3.08056C17.4308 3.06957 17.5153 3.07661 17.5956 3.1012C17.6758 3.12579 17.7498 3.16735 17.8126 3.22306C17.8717 3.27591 17.9189 3.34064 17.9512 3.41302C17.9835 3.4854 18.0002 3.56379 18.0001 3.64306V16.6256C18.0043 16.7989 17.9483 16.9684 17.8417 17.1052C17.735 17.2419 17.5843 17.3375 17.4151 17.3756C15.6621 17.6746 14.038 18.4893 12.7501 19.7156V5.54806C13.9206 4.18024 15.5607 3.30001 17.3476 3.08056ZM6.00007 3.64306C6.00201 3.49249 6.06269 3.34864 6.16917 3.24216C6.27565 3.13568 6.4195 3.075 6.57007 3.07306H6.65257C8.44054 3.29446 10.0808 4.17745 11.2501 5.54806V19.7156C9.96406 18.4838 8.33977 17.6639 6.58507 17.3606C6.41588 17.3225 6.26513 17.2269 6.15847 17.0902C6.05181 16.9534 5.99583 16.7839 6.00007 16.6106V3.64306ZM3.84757 19.9031C3.74122 19.917 3.63311 19.908 3.53054 19.8766C3.42797 19.8452 3.33333 19.7922 3.25301 19.7211C3.17268 19.65 3.10853 19.5625 3.0649 19.4645C3.02127 19.3665 2.99916 19.2603 3.00007 19.1531V6.45556C2.99653 6.2801 3.05464 6.10896 3.16427 5.97192C3.2739 5.83488 3.42811 5.74062 3.60007 5.70556C3.90007 5.64556 4.20007 5.60056 4.50007 5.55556V16.6256C4.49992 17.1508 4.68357 17.6596 5.01917 18.0637C5.35478 18.4678 5.82119 18.7418 6.33757 18.8381C7.44079 19.0318 8.48499 19.4757 9.39007 20.1356C7.57088 19.7308 5.69428 19.652 3.84757 19.9031ZM21.0001 19.1531C21.001 19.2603 20.9789 19.3665 20.9352 19.4645C20.8916 19.5625 20.8275 19.65 20.7471 19.7211C20.6668 19.7922 20.5722 19.8452 20.4696 19.8766C20.367 19.908 20.2589 19.917 20.1526 19.9031C18.3059 19.652 16.4293 19.7308 14.6101 20.1356C15.5152 19.4757 16.5593 19.0318 17.6626 18.8381C18.179 18.7418 18.6454 18.4678 18.981 18.0637C19.3166 17.6596 19.5002 17.1508 19.5001 16.6256V5.57056C19.8001 5.61556 20.1001 5.66056 20.4076 5.72056C20.5781 5.75715 20.7306 5.85206 20.8388 5.98895C20.9469 6.12584 21.004 6.29615 21.0001 6.47056V19.1531Z" fill="currentColor"/>
                    </svg>                      
                    Lessons :
                  </span>
                  <span class="td_semibold td_accent_color">12</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M19.3462 15.852V13.3536L18.2918 13.7638L18.2887 13.7569L18.2636 13.7112C17.8596 13.0822 17.2062 12.6445 16.4704 12.5111L13.9333 12.0495V11.8492C14.8821 11.2983 15.5769 10.3583 15.7934 9.24716C16.4963 9.10178 17.0264 8.47814 17.0264 7.73271V3.91391C17.0264 2.83481 16.3196 1.89374 15.2943 1.58752L15.1009 1.39421C14.2016 0.494893 13.0061 0 11.7345 0C9.10963 0 6.97386 2.13539 6.97386 4.76064V7.73271C6.97386 8.47814 7.50394 9.10178 8.20684 9.24716C8.42374 10.3583 9.11814 11.2986 10.0669 11.8492V12.0495L7.53023 12.5107C6.79523 12.6441 6.14221 13.081 5.73779 13.7097L5.71459 13.7661L4.65405 13.3536V15.852C4.01455 15.852 3.49414 16.3725 3.49414 17.012V18.5585C3.49414 19.198 4.01455 19.7184 4.65405 19.7184V21.1428L12.0001 24L19.3462 21.1428V19.7184C19.9857 19.7184 20.5061 19.198 20.5061 18.5585V17.012C20.5061 16.3725 19.9857 15.852 19.3462 15.852ZM14.6578 12.9674L16.332 13.2716C16.8249 13.3613 17.2615 13.6459 17.5526 14.0511L13.8119 15.5056L14.6578 12.9674ZM10.8731 12.2038C11.2299 12.3128 11.6081 12.3723 12.0001 12.3723C12.3922 12.3723 12.7703 12.3128 13.1272 12.2038L12.0001 13.0489L10.8731 12.2038ZM11.4117 13.574L10.6225 14.3627L10.1106 12.8274L10.3569 12.7829L11.4117 13.574ZM13.6433 12.7833L13.8896 12.8278L13.3777 14.3631L12.5886 13.5744L13.6433 12.7833ZM15.8665 8.39849V7.06692C16.0965 7.20108 16.2531 7.44776 16.2531 7.73271C16.2531 8.01766 16.0965 8.26433 15.8665 8.39849ZM8.13376 8.39849C7.90372 8.26433 7.74713 8.01766 7.74713 7.73271C7.74713 7.44776 7.90372 7.20108 8.13376 7.06692V8.39849ZM8.13376 5.79953V6.24107C7.99612 6.27702 7.86699 6.33115 7.74713 6.40113V4.76064C7.74713 2.56223 9.5357 0.773271 11.7345 0.773271C12.7993 0.773271 13.8011 1.18813 14.5542 1.9413L14.8952 2.28269L14.9992 2.30821C15.7377 2.49264 16.2531 3.15301 16.2531 3.91391V6.40113C16.1332 6.33115 16.0041 6.27664 15.8665 6.24107V5.79953H14.6405C13.5927 5.79953 12.5913 5.29922 11.963 4.46138L11.6556 4.05078L10.8874 4.81941C10.2548 5.45156 9.4143 5.79953 8.5204 5.79953H8.13376ZM8.90704 8.50598V6.55502C9.86164 6.46648 10.7474 6.05239 11.4341 5.36611L11.5845 5.21571C12.3597 6.07133 13.4763 6.5728 14.6405 6.5728H15.0932V8.50598C15.0932 10.2114 13.7056 11.5991 12.0001 11.5991C10.2947 11.5991 8.90704 10.2114 8.90704 8.50598ZM7.66826 13.2716L9.34239 12.9674L10.1883 15.5056L6.44687 14.0507C6.73801 13.6451 7.1753 13.3613 7.66826 13.2716ZM4.26741 18.5585V17.012C4.26741 16.7985 4.44101 16.6253 4.65405 16.6253C5.29354 16.6253 5.81395 17.1457 5.81395 17.7852C5.81395 18.4247 5.29354 18.9451 4.65405 18.9451C4.44101 18.9451 4.26741 18.7719 4.26741 18.5585ZM11.6135 23.0195L5.42732 20.6142V19.5545C6.10896 19.2552 6.58722 18.5759 6.58722 17.7852C6.58722 16.9946 6.10896 16.3152 5.42732 16.016V14.4841L11.6135 16.8898V23.0195ZM10.4656 15.6139L12.0001 14.0789L13.5347 15.6135L12.0001 16.2105L10.4656 15.6139ZM18.5729 20.6138L12.3868 23.0191V16.8898L18.5729 14.4841V16.016C17.8913 16.3152 17.413 16.9946 17.413 17.7852C17.413 18.5759 17.8913 19.2552 18.5729 19.5545V20.6138ZM19.7328 18.5585C19.7328 18.7719 19.5592 18.9451 19.3462 18.9451C18.7067 18.9451 18.1863 18.4247 18.1863 17.7852C18.1863 17.1457 18.7067 16.6253 19.3462 16.6253C19.5592 16.6253 19.7328 16.7985 19.7328 17.012V18.5585Z" fill="currentColor"/>
                    </svg>                      
                    Students :
                  </span>
                  <span class="td_semibold td_accent_color">230</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <g clip-path="url(#clip0_34_14814)">
                      <path d="M9.17392 12.5653C9.13543 12.3726 7.80971 5.74402 7.76767 5.53397C7.702 5.20533 7.41339 4.96875 7.07823 4.96875H5.67198C5.33682 4.96875 5.04822 5.20533 4.98254 5.53397C4.93984 5.74758 3.61276 12.3829 3.57629 12.5652C3.50012 12.946 3.74711 13.3164 4.12787 13.3926C4.50864 13.4687 4.87909 13.2218 4.95522 12.841L5.40465 10.5938H7.34556L7.795 12.841C7.87117 13.222 8.24176 13.4688 8.62234 13.3926C9.00311 13.3164 9.25009 12.946 9.17392 12.5653ZM5.6859 9.1875L6.2484 6.375H6.50181L7.06431 9.1875H5.6859Z" fill="currentColor"/>
                      <path d="M20.4375 10.5938H18.3281V9.89062C18.3281 9.50231 18.0133 9.1875 17.625 9.1875C17.2367 9.1875 16.9219 9.50231 16.9219 9.89062V10.5938H14.8125C14.4242 10.5938 14.1094 10.9086 14.1094 11.2969C14.1094 11.6852 14.4242 12 14.8125 12H14.9827C15.3833 13.2943 15.9865 14.2878 16.6502 15.0839C16.11 15.5781 15.5633 15.9833 15.0764 16.3728C14.7732 16.6154 14.724 17.0579 14.9666 17.3611C15.2093 17.6645 15.6518 17.7134 15.9549 17.4709C16.4445 17.0791 17.0315 16.6438 17.625 16.0991C18.219 16.6442 18.807 17.0803 19.2951 17.4709C19.5983 17.7135 20.0408 17.6643 20.2834 17.3611C20.526 17.0579 20.4768 16.6154 20.1736 16.3728C19.6879 15.9842 19.1406 15.5785 18.5998 15.0839C19.2635 14.2878 19.8667 13.2943 20.2673 12H20.4375C20.8258 12 21.1406 11.6852 21.1406 11.2969C21.1406 10.9086 20.8258 10.5938 20.4375 10.5938ZM17.625 14.0505C17.1762 13.4871 16.7724 12.8146 16.468 11.9953H18.782C18.4776 12.8146 18.0738 13.4871 17.625 14.0505Z" fill="currentColor"/>
                      <path d="M21.8906 4.26562H11.7468L11.4454 1.84772C11.3138 0.794344 10.4139 0 9.35236 0H2.10938C0.946266 0 0 0.946266 0 2.10938V17.625C0 18.7881 0.946266 19.7344 2.10938 19.7344H8.03827L8.33583 22.1523C8.46727 23.2035 9.36708 24 10.4289 24H21.8906C23.0537 24 24 23.0537 24 21.8906V6.375C24 5.21189 23.0537 4.26562 21.8906 4.26562ZM2.10938 18.3281C1.72167 18.3281 1.40625 18.0127 1.40625 17.625V2.10938C1.40625 1.72167 1.72167 1.40625 2.10938 1.40625H9.35236C9.70622 1.40625 10.0062 1.671 10.05 2.02191C10.1519 2.83922 11.9816 17.5174 12.0827 18.3281H2.10938ZM9.69019 21.6445L9.45511 19.7344H11.3415L9.69019 21.6445ZM22.5938 21.8906C22.5938 22.2783 22.2783 22.5938 21.8906 22.5938H10.7285L13.4052 19.4975C13.5422 19.343 13.6036 19.1378 13.5753 18.9339L11.9221 5.67188H21.8906C22.2783 5.67188 22.5938 5.9873 22.5938 6.375V21.8906Z" fill="currentColor"/>
                      </g>
                      <defs>
                      <clipPath id="clip0_34_14814">
                      <rect width="24" height="24" fill="white"/>
                      </clipPath>
                      </defs>
                    </svg>                      
                    Language :
                  </span>
                  <span class="td_semibold td_accent_color">English</span>
                </li>
                <li>
                  <span>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22 1.60156H2C0.895979 1.60288 0.00132245 2.49754 0 3.60156V18.0016C0.00132245 19.1056 0.895979 20.0002 2 20.0016H14V22.0016C14 22.1633 14.0975 22.3091 14.2469 22.371C14.3964 22.4329 14.5684 22.3987 14.6828 22.2844L16 20.9672L17.3172 22.2844C17.4316 22.3987 17.6036 22.4329 17.7531 22.371C17.9025 22.3091 18 22.1633 18 22.0016V20.0016H22C23.104 20.0002 23.9987 19.1056 24 18.0016V3.60156C23.9987 2.49754 23.104 1.60288 22 1.60156ZM12.924 9.42756C12.8622 9.39904 12.8177 9.34265 12.8044 9.27587C12.7911 9.20909 12.8106 9.13999 12.8568 9.08996C13.2147 8.70097 13.2147 8.10256 12.8568 7.71356C12.8105 7.66348 12.7909 7.59421 12.8043 7.52731C12.8177 7.4604 12.8624 7.40397 12.9244 7.37556C13.4036 7.15259 13.6323 6.59993 13.4508 6.10356C13.4272 6.03966 13.4356 5.96831 13.4734 5.91164C13.5112 5.85498 13.5739 5.81985 13.642 5.81716C14.1702 5.79497 14.5934 5.3718 14.6156 4.84356C14.6182 4.77538 14.6534 4.71261 14.7102 4.67476C14.767 4.63691 14.8384 4.62858 14.9024 4.65236C15.3988 4.83275 15.9509 4.60413 16.1744 4.12556C16.2027 4.06361 16.259 4.01902 16.3258 4.00571C16.3926 3.9924 16.4617 4.01199 16.5116 4.05836C16.9007 4.41633 17.4993 4.41633 17.8884 4.05836C17.9384 4.01202 18.0076 3.9925 18.0745 4.00589C18.1413 4.01927 18.1977 4.06394 18.226 4.12596C18.4491 4.60476 19.0014 4.83338 19.4976 4.65236C19.5616 4.62858 19.633 4.63691 19.6898 4.67476C19.7466 4.71261 19.7818 4.77538 19.7844 4.84356C19.8068 5.37253 20.231 5.79599 20.76 5.81756C20.828 5.82012 20.8907 5.85515 20.9286 5.91177C20.9664 5.96838 20.9748 6.0397 20.9512 6.10356C20.7696 6.60004 20.9985 7.15287 21.478 7.37556C21.5398 7.40408 21.5843 7.46047 21.5976 7.52725C21.6109 7.59403 21.5914 7.66314 21.5452 7.71316C21.1873 8.10216 21.1873 8.70057 21.5452 9.08956C21.5915 9.13964 21.6111 9.20891 21.5977 9.27582C21.5843 9.34272 21.5396 9.39916 21.4776 9.42756C20.9984 9.65054 20.7697 10.2032 20.9512 10.6996C20.9748 10.7635 20.9664 10.8348 20.9286 10.8915C20.8908 10.9481 20.8281 10.9833 20.76 10.986C20.2302 11.0072 19.8057 11.4318 19.7844 11.9616C19.7818 12.0297 19.7466 12.0925 19.6898 12.1304C19.633 12.1682 19.5616 12.1765 19.4976 12.1528C19.0011 11.9722 18.449 12.2008 18.2256 12.6796C18.1984 12.7421 18.1419 12.7871 18.0748 12.7996C18.0078 12.8136 17.9383 12.794 17.8884 12.7472C17.4992 12.3894 16.9008 12.3894 16.5116 12.7472C16.4617 12.7939 16.3922 12.8135 16.3252 12.7996C16.258 12.787 16.2014 12.7421 16.174 12.6796C15.951 12.2006 15.3986 11.9719 14.9024 12.1532C14.8384 12.1769 14.767 12.1686 14.7102 12.1308C14.6534 12.0929 14.6182 12.0301 14.6156 11.962C14.5944 11.4321 14.1699 11.0072 13.64 10.9856C13.572 10.983 13.5093 10.948 13.4714 10.8914C13.4336 10.8347 13.4252 10.7634 13.4488 10.6996C13.6307 10.2036 13.4027 9.65097 12.924 9.42756ZM17.3176 16.9184L17.2 17.036V13.276C17.2535 13.2758 17.3051 13.296 17.3444 13.3324C17.5298 13.5061 17.7743 13.6028 18.0284 13.6028C18.0964 13.6026 18.1641 13.5959 18.2308 13.5828C18.5491 13.5206 18.8175 13.308 18.9508 13.0124C18.9977 12.9115 19.1141 12.8635 19.2184 12.902C19.3401 12.9451 19.469 12.9645 19.598 12.9592V17.036L18.6808 16.1188C18.5246 15.9626 18.2714 15.9626 18.1152 16.1188L17.3176 16.9184ZM17.2 21.036L16.2828 20.1188C16.1266 19.9626 15.8734 19.9626 15.7172 20.1188L14.8 21.036V12.9584C14.929 12.9637 15.0579 12.9443 15.1796 12.9012C15.2837 12.8625 15.4001 12.9104 15.4468 13.0112C15.5805 13.3076 15.8499 13.5205 16.1692 13.582C16.2452 13.597 16.3226 13.6036 16.4 13.6016V18.0016C16.4 18.1633 16.4975 18.3091 16.6469 18.371C16.7964 18.4329 16.9684 18.3987 17.0828 18.2844L17.2 18.1672V21.036ZM23.2 18.0016C23.2 18.6643 22.6627 19.2016 22 19.2016H18V17.3672L18.4 16.9672L19.7172 18.2844C19.8316 18.3987 20.0036 18.4329 20.1531 18.371C20.3025 18.3091 20.4 18.1633 20.4 18.0016V12.5244C20.5116 12.3676 20.5754 12.1818 20.5836 11.9896C20.5885 11.8786 20.6774 11.7898 20.7884 11.7852C21.1127 11.7727 21.4113 11.6055 21.5916 11.3357C21.7718 11.0658 21.8118 10.7259 21.6992 10.4216C21.661 10.3175 21.709 10.2015 21.8096 10.1548C22.1046 10.0192 22.3168 9.75046 22.3801 9.43202C22.4435 9.11358 22.3503 8.78409 22.1296 8.54596C22.0544 8.46422 22.0544 8.3385 22.1296 8.25676C22.3503 8.01871 22.4435 7.68927 22.3801 7.37088C22.3168 7.0525 22.1046 6.7838 21.8096 6.64836C21.7087 6.60196 21.6605 6.48578 21.6988 6.38156C21.8114 6.07722 21.7714 5.73733 21.5912 5.46747C21.4109 5.19761 21.1123 5.03047 20.788 5.01796C20.677 5.0133 20.5881 4.92452 20.5832 4.81356C20.5711 4.48917 20.4041 4.19026 20.1343 4.00981C19.8644 3.82936 19.5244 3.78925 19.22 3.90196C19.1159 3.94128 18.9991 3.8932 18.9528 3.79196C18.8173 3.49693 18.5485 3.28477 18.2301 3.22143C17.9116 3.15809 17.5821 3.25126 17.344 3.47196C17.2624 3.54709 17.1368 3.54709 17.0552 3.47196C16.8172 3.25125 16.4877 3.15808 16.1693 3.22142C15.8509 3.28477 15.5822 3.49694 15.4468 3.79196C15.4004 3.89326 15.2836 3.94146 15.1792 3.90236C14.8748 3.78965 14.5348 3.82976 14.2649 4.01021C13.9951 4.19066 13.8281 4.48957 13.816 4.81396C13.8111 4.92492 13.7222 5.0137 13.6112 5.01836C13.2869 5.03087 12.9883 5.19801 12.808 5.46787C12.6278 5.73773 12.5878 6.07762 12.7004 6.38196C12.7386 6.48607 12.6906 6.60207 12.59 6.64876C12.295 6.7843 12.0828 7.05307 12.0195 7.37151C11.9561 7.68994 12.0493 8.01944 12.27 8.25756C12.3452 8.3393 12.3452 8.46502 12.27 8.54676C12.0493 8.78481 11.9561 9.11426 12.0195 9.43264C12.0828 9.75102 12.295 10.0197 12.59 10.1552C12.6909 10.2016 12.7391 10.3177 12.7008 10.422C12.5882 10.7263 12.6282 11.0662 12.8084 11.3361C12.9887 11.6059 13.2873 11.7731 13.6116 11.7856C13.7226 11.7902 13.8115 11.879 13.8164 11.99C13.8247 12.1821 13.8884 12.3677 14 12.5244V19.2016H2C1.33726 19.2016 0.8 18.6643 0.8 18.0016V3.60156C0.8 2.93882 1.33726 2.40156 2 2.40156H22C22.6627 2.40156 23.2 2.93882 23.2 3.60156V18.0016Z" fill="currentColor"/>
                      <path d="M4.3999 16.0047C3.73716 16.0047 3.1999 15.4674 3.1999 14.8047V6.80469C3.1999 6.14195 3.73716 5.60469 4.3999 5.60469H11.5999C11.8208 5.60469 11.9999 5.4256 11.9999 5.20469C11.9999 4.98377 11.8208 4.80469 11.5999 4.80469H4.3999C3.29588 4.80601 2.40122 5.70067 2.3999 6.80469V14.8047C2.40122 15.9087 3.29588 16.8034 4.3999 16.8047H11.9999C12.2208 16.8047 12.3999 16.6256 12.3999 16.4047C12.3999 16.1838 12.2208 16.0047 11.9999 16.0047H4.3999Z" fill="currentColor"/>
                      <path d="M4.7999 11.1984H10.3999C10.6208 11.1984 10.7999 11.0194 10.7999 10.7984C10.7999 10.5775 10.6208 10.3984 10.3999 10.3984H4.7999C4.57899 10.3984 4.3999 10.5775 4.3999 10.7984C4.3999 11.0194 4.57899 11.1984 4.7999 11.1984Z" fill="currentColor"/>
                      <path d="M4.7999 9.60469H10.3999C10.6208 9.60469 10.7999 9.4256 10.7999 9.20469C10.7999 8.98377 10.6208 8.80469 10.3999 8.80469H4.7999C4.57899 8.80469 4.3999 8.98377 4.3999 9.20469C4.3999 9.4256 4.57899 9.60469 4.7999 9.60469Z" fill="currentColor"/>
                      <path d="M4.7999 8.00313H10.3999C10.6208 8.00313 10.7999 7.82404 10.7999 7.60313C10.7999 7.38221 10.6208 7.20312 10.3999 7.20312H4.7999C4.57899 7.20312 4.3999 7.38221 4.3999 7.60313C4.3999 7.82404 4.57899 8.00313 4.7999 8.00313Z" fill="currentColor"/>
                      <path d="M4.43334 14.9643C4.49698 15.1102 4.64102 15.2044 4.80014 15.2043C4.8552 15.2046 4.90971 15.1933 4.96014 15.1711C5.33046 15.0336 5.67079 14.8259 5.96254 14.5595C6.07084 14.4515 6.16554 14.3306 6.24454 14.1995C6.39728 14.3713 6.5768 14.5171 6.77614 14.6315C7.05414 14.8133 7.40015 14.8575 7.71494 14.7515C7.8356 14.7047 7.94475 14.6324 8.03494 14.5395C8.21594 14.6526 8.41535 14.7332 8.62414 14.7775L8.92654 14.8491C9.54378 15.0299 10.1851 15.1149 10.8281 15.1011C10.9707 15.0908 11.0969 15.0053 11.1593 14.8767C11.2216 14.7481 11.2107 14.596 11.1305 14.4777C11.0503 14.3594 10.9131 14.2928 10.7705 14.3031C10.2094 14.3105 9.65047 14.2322 9.11294 14.0711L8.80374 13.9979C8.43054 13.9119 8.33454 13.7615 8.29494 13.6555C8.22523 13.4694 8.02946 13.3627 7.83527 13.405C7.64108 13.4473 7.50737 13.6257 7.52134 13.8239C7.52581 13.8957 7.49184 13.9643 7.43214 14.0043C7.33868 14.0162 7.24422 13.9919 7.16814 13.9363C6.84465 13.7349 6.60139 13.4272 6.48014 13.0659C6.41131 12.8799 6.21658 12.7724 6.02251 12.8133C5.82843 12.8542 5.69364 13.0312 5.70574 13.2291C5.71247 13.5153 5.60039 13.7914 5.39614 13.9919C5.17403 14.1862 4.91765 14.3373 4.64014 14.4375C4.54282 14.4799 4.46635 14.5593 4.42756 14.6581C4.38878 14.7569 4.39085 14.8671 4.43334 14.9643Z" fill="currentColor"/>
                      <path d="M17.2 11.6031C18.9673 11.6031 20.4 10.1704 20.4 8.40313C20.4 6.63581 18.9673 5.20312 17.2 5.20312C15.4327 5.20312 14 6.63581 14 8.40313C14.002 10.1696 15.4335 11.6011 17.2 11.6031ZM17.2 6.00313C18.5255 6.00313 19.6 7.07764 19.6 8.40313C19.6 9.72861 18.5255 10.8031 17.2 10.8031C15.8745 10.8031 14.8 9.72861 14.8 8.40313C14.8013 7.07819 15.8751 6.00445 17.2 6.00313Z" fill="currentColor"/>
                    </svg>                      
                    Certifications :
                  </span>
                  <span class="td_semibold td_accent_color">Yes</span>
                </li>
              </ul>
              <div class="td_height_30 td_height_lg_30"></div>
              <a href="cart.html" class="td_btn td_style_1 td_radius_10 td_medium w-100">
                <span class="td_btn_in td_white_color td_accent_bg">
                  <span>Buy Now</span>
                </span>             
              </a>
              <div class="td_height_40 td_height_lg_30"></div>
              <h3 class="td_fs_20 td_semibold td_mb_15">Share On:</h3>
              <div class="td_footer_social_btns td_fs_18 td_accent_color">
                <a href="#" class="td_center">
                  <i class="fa-brands fa-facebook-f"></i>
                </a>
                <a href="#" class="td_center">
                  <i class="fa-brands fa-x-twitter"></i>
                </a>
                <a href="#" class="td_center">
                  <i class="fa-brands fa-instagram"></i>
                </a>
                <a href="#" class="td_center">
                  <i class="fa-brands fa-pinterest-p"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Course Details Section -->


    
    <!-- Start Popular Courses -->
    <section>
      <div class="td_height_60 td_height_lg_60"></div>
      <div class="container">
        <h2 class="td_fs_48 td_mb_50">Courses you May Like</h2>
        <div class="row td_gap_y_30 td_row_gap_30">
          <div class="col-lg-4 col-md-6">
            <div class="td_card td_style_3 d-block td_radius_10">
              <span class="td_card_label td_accent_bg td_white_color">New</span>
              <a href="course-details.html" class="td_card_thumb">
<img src="{{ asset('assets/img/home_1/course_thumb_1.jpg') }}" alt="">
              </a>
              <div class="td_card_info td_white_bg">
                <div class="td_card_info_in">
                  <ul class="td_card_meta td_mp_0 td_fs_18 td_medium td_heading_color">
  <li>
    <img src="{{ asset('assets/img/icons/user_3.svg') }}" alt="">
    <span class="td_opacity_7">150 Seats</span>
  </li>
  <li>
    <img src="{{ asset('assets/img/icons/book.svg') }}" alt="">
    <span class="td_opacity_7">12 Semesters</span>
  </li>
</ul>

                  <a href="courses-grid-with-sidebar.html" class="td_card_category td_fs_14 td_bold td_heading_color td_mb_14"><span>Data Analytics</span></a>
                  <h2 class="td_card_title td_fs_24 td_mb_16"><a href="course-details.html">Starting Reputed Education & Build your Skills</a></h2>
                  <p class="td_card_subtitle td_heading_color td_opacity_7 td_mb_20">Far far away, behind the word mountains, far from the Consonantia.</p>
                  <div class="td_card_review">
                    <div class="td_rating" data-rating="4.5">
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <div class="td_rating_percentage">
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                      </div>
                    </div>
                    <span class="td_heading_color td_opacity_5 td_medium">(5.0/5 Ratings)</span>
                  </div>
                  <div class="td_card_btn">
                    <a href="cart.html" class="td_btn td_style_1 td_radius_10 td_medium">
                      <span class="td_btn_in td_white_color td_accent_bg">
                        <span>Enroll Now</span>
                      </span>             
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="td_card td_style_3 d-block td_radius_10">
              <span class="td_card_label td_accent_bg td_white_color">New</span>
              <a href="course-details.html" class="td_card_thumb">
<img src="{{ asset('assets/img/home_1/course_thumb_2.jpg') }}" alt="">

              </a>
              <div class="td_card_info td_white_bg">
                <div class="td_card_info_in">
                 <ul class="td_card_meta td_mp_0 td_fs_18 td_medium td_heading_color">
  <li>
    <img src="{{ asset('assets/img/icons/user_3.svg') }}" alt="">
    <span class="td_opacity_7">100 Seats</span>
  </li>
  <li>
    <img src="{{ asset('assets/img/icons/book.svg') }}" alt="">
    <span class="td_opacity_7">20 Semesters</span>
  </li>
</ul>

                  <a href="courses-grid-with-sidebar.html" class="td_card_category td_fs_14 td_bold td_heading_color td_mb_14"><span>Software Engeneer</span></a>
                  <h2 class="td_card_title td_fs_24 td_mb_16"><a href="course-details.html">Master Technology & Elevate Your Career</a></h2>
                  <p class="td_card_subtitle td_heading_color td_opacity_7 td_mb_20">Unlock the power of technology to drive your career forward.</p>
                  <div class="td_card_review">
                    <div class="td_rating" data-rating="5">
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <div class="td_rating_percentage">
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                      </div>
                    </div>
                    <span class="td_heading_color td_opacity_5 td_medium">(5.0/10 Ratings)</span>
                  </div>
                  <div class="td_card_btn">
                    <a href="cart.html" class="td_btn td_style_1 td_radius_10 td_medium">
                      <span class="td_btn_in td_white_color td_accent_bg">
                        <span>Enroll Now</span>
                      </span>             
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="td_card td_style_3 d-block td_radius_10">
              <span class="td_card_label td_accent_bg td_white_color">New</span>
              <a href="course-details.html" class="td_card_thumb">
<img src="{{ asset('assets/img/home_1/course_thumb_3.jpg') }}" alt="">
              </a>
              <div class="td_card_info td_white_bg">
                <div class="td_card_info_in">
                  <ul class="td_card_meta td_mp_0 td_fs_18 td_medium td_heading_color">
  <li>
    <img src="{{ asset('assets/img/icons/user_3.svg') }}" alt="">
    <span class="td_opacity_7">300 Seats</span>
  </li>
  <li>
    <img src="{{ asset('assets/img/icons/book.svg') }}" alt="">
    <span class="td_opacity_7">8 Semesters</span>
  </li>
</ul>

                  <a href="courses-grid-with-sidebar.html" class="td_card_category td_fs_14 td_bold td_heading_color td_mb_14"><span>Bachelor Of Arts</span></a>
                  <h2 class="td_card_title td_fs_24 td_mb_16"><a href="course-details.html">Boost Creativity & Expand Your Horizons</a></h2>
                  <p class="td_card_subtitle td_heading_color td_opacity_7 td_mb_20">Discover innovative techniques to enhance your creative thinking.</p>
                  <div class="td_card_review">
                    <div class="td_rating" data-rating="5">
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <i class="fa-regular fa-star"></i>
                      <div class="td_rating_percentage">
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                        <i class="fa-solid fa-star fa-fw"></i>
                      </div>
                    </div>
                    <span class="td_heading_color td_opacity_5 td_medium">(5.0/12 Ratings)</span>
                  </div>
                  <div class="td_card_btn">
                    <a href="cart.html" class="td_btn td_style_1 td_radius_10 td_medium">
                      <span class="td_btn_in td_white_color td_accent_bg">
                        <span>Enroll Now</span>
                      </span>             
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="td_height_120 td_height_lg_80"></div>
    </section>
    <!-- End Popular Courses -->


